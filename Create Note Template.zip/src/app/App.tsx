import { useState, useEffect, useRef } from "react";

// ─── Palette ───────────────────────────────────────────────────────────────────
const C = {
  spaceCadet: "#102B53",
  ucla: "#50698D",
  lavender: "#CEB5D4",
  azure: "#4E7AB1",
  air: "#7D9FC0",
  paper: "#F4F7FC",
};

// ─── Shared helpers ─────────────────────────────────────────────────────────────
function DotPaper() {
  return (
    <div
      className="absolute inset-0 pointer-events-none"
      style={{
        backgroundImage: `radial-gradient(circle, ${C.azure}28 1.1px, transparent 1.1px)`,
        backgroundSize: "22px 22px",
      }}
    />
  );
}

function PageNumber({ n }: { n: number }) {
  return (
    <div
      className="absolute bottom-5 right-7 text-xs font-mono tracking-widest opacity-50"
      style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}
    >
      {n} / 7
    </div>
  );
}

function Divider({ className = "" }: { className?: string }) {
  return (
    <div
      className={`border-t my-4 ${className}`}
      style={{ borderColor: `${C.azure}28` }}
    />
  );
}

function TagBadge({
  children,
  color = C.azure,
}: {
  children: React.ReactNode;
  color?: string;
}) {
  return (
    <span
      className="inline-block text-xs font-bold tracking-widest px-2 py-0.5 rounded-full mr-1 mb-1"
      style={{
        backgroundColor: `${color}20`,
        color,
        fontFamily: "'DM Mono', monospace",
      }}
    >
      {children}
    </span>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase mb-3 px-3 py-1 rounded-full"
      style={{
        backgroundColor: `${C.azure}18`,
        color: C.azure,
        fontFamily: "'DM Mono', monospace",
      }}
    >
      {children}
    </div>
  );
}

type BoxType = "key" | "remember" | "mistake" | "formula" | "info";

function Box({
  type,
  title,
  children,
}: {
  type: BoxType;
  title?: string;
  children: React.ReactNode;
}) {
  const map: Record<BoxType, { bg: string; border: string; label: string; icon: string }> = {
    key: { bg: `${C.azure}12`, border: C.azure, label: "KEY POINT", icon: "★" },
    remember: { bg: `${C.lavender}22`, border: C.lavender, label: "REMEMBER", icon: "♡" },
    mistake: { bg: "#E0525218", border: "#C04040", label: "COMMON MISTAKE", icon: "✕" },
    formula: { bg: `${C.spaceCadet}08`, border: C.spaceCadet, label: "FORMULA", icon: "f(x)" },
    info: { bg: `${C.air}18`, border: C.air, label: "NOTE", icon: "ℹ" },
  };
  const s = map[type];
  return (
    <div
      className="rounded-xl p-3.5 mb-3"
      style={{ backgroundColor: s.bg, borderLeft: `3px solid ${s.border}` }}
    >
      <div
        className="text-xs font-bold tracking-widest mb-1.5 flex items-center gap-1.5"
        style={{ color: s.border, fontFamily: "'DM Mono', monospace" }}
      >
        <span>{s.icon}</span>
        <span>{title || s.label}</span>
      </div>
      <div className="text-sm leading-relaxed" style={{ color: C.spaceCadet }}>
        {children}
      </div>
    </div>
  );
}

function BulletItem({
  children,
  color = C.azure,
}: {
  children: React.ReactNode;
  color?: string;
}) {
  return (
    <li className="flex items-start gap-2 mb-1.5 text-sm" style={{ color: C.spaceCadet }}>
      <span className="mt-0.5 text-xs" style={{ color }}>◆</span>
      <span className="leading-relaxed">{children}</span>
    </li>
  );
}

function CheckItem({
  ok,
  children,
}: {
  ok: boolean;
  children: React.ReactNode;
}) {
  return (
    <li className="flex items-start gap-2 mb-1.5 text-sm" style={{ color: C.spaceCadet }}>
      <span
        className="mt-0.5 text-xs font-bold"
        style={{ color: ok ? "#3A8A5A" : "#C04040" }}
      >
        {ok ? "✓" : "✕"}
      </span>
      <span className="leading-relaxed">{children}</span>
    </li>
  );
}

// ─── SVG Diagrams ───────────────────────────────────────────────────────────────

function DaltonAtom({ size = 90 }: { size?: number }) {
  return (
    <svg viewBox="0 0 90 90" width={size} height={size}>
      <defs>
        <radialGradient id="dg" cx="35%" cy="30%">
          <stop offset="0%" stopColor={C.air} />
          <stop offset="60%" stopColor={C.azure} />
          <stop offset="100%" stopColor={C.spaceCadet} />
        </radialGradient>
      </defs>
      <circle cx="45" cy="45" r="36" fill="url(#dg)" />
    </svg>
  );
}

function ThomsonAtom({ size = 90 }: { size?: number }) {
  const electrons = [
    [32, 28], [54, 24], [66, 40], [60, 60], [40, 68], [22, 56], [20, 36],
  ];
  return (
    <svg viewBox="0 0 90 90" width={size} height={size}>
      <defs>
        <radialGradient id="tg" cx="50%" cy="50%">
          <stop offset="0%" stopColor="#EDD8F5" />
          <stop offset="100%" stopColor={C.lavender} />
        </radialGradient>
      </defs>
      <circle cx="45" cy="45" r="36" fill="url(#tg)" stroke={C.ucla} strokeWidth="1" />
      {electrons.map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="5" fill={C.spaceCadet} />
          <text x={x} y={y + 2} textAnchor="middle" fontSize="5.5" fill="white" fontFamily="serif">−</text>
        </g>
      ))}
    </svg>
  );
}

function RutherfordAtom({ size = 100 }: { size?: number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size}>
      <ellipse cx="50" cy="50" rx="44" ry="16" fill="none" stroke={C.azure} strokeWidth="1.2" strokeDasharray="3 2" transform="rotate(-40 50 50)" opacity="0.7" />
      <ellipse cx="50" cy="50" rx="44" ry="16" fill="none" stroke={C.azure} strokeWidth="1.2" strokeDasharray="3 2" transform="rotate(20 50 50)" opacity="0.7" />
      <ellipse cx="50" cy="50" rx="44" ry="16" fill="none" stroke={C.azure} strokeWidth="1.2" strokeDasharray="3 2" transform="rotate(80 50 50)" opacity="0.7" />
      <circle cx="50" cy="50" r="8" fill={C.spaceCadet} />
      <text x="50" y="53.5" textAnchor="middle" fontSize="6.5" fill={C.lavender} fontWeight="bold">+</text>
      {[[50, 7], [92, 68], [12, 72]].map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="5" fill={C.lavender} />
          <text x={x} y={y + 2} textAnchor="middle" fontSize="5.5" fill={C.spaceCadet} fontFamily="serif">−</text>
        </g>
      ))}
    </svg>
  );
}

function BohrAtom({ size = 110 }: { size?: number }) {
  return (
    <svg viewBox="0 0 110 110" width={size} height={size}>
      <circle cx="55" cy="55" r="16" fill="none" stroke={C.air} strokeWidth="1.3" />
      <circle cx="55" cy="55" r="30" fill="none" stroke={C.air} strokeWidth="1.3" />
      <circle cx="55" cy="55" r="46" fill="none" stroke={C.air} strokeWidth="1.3" />
      <circle cx="55" cy="55" r="10" fill={C.spaceCadet} />
      <text x="55" y="58.5" textAnchor="middle" fontSize="6" fill={C.lavender} fontWeight="bold">N+</text>
      {/* K shell */}
      {[[55, 39]].map(([x, y], i) => (
        <g key={`k${i}`}>
          <circle cx={x} cy={y} r="4.5" fill={C.lavender} />
          <text x={x} y={y + 1.8} textAnchor="middle" fontSize="4.5" fill={C.spaceCadet}>−</text>
        </g>
      ))}
      {/* L shell */}
      {[[85, 55], [25, 55], [55, 25]].map(([x, y], i) => (
        <g key={`l${i}`}>
          <circle cx={x} cy={y} r="4.5" fill={C.lavender} />
          <text x={x} y={y + 1.8} textAnchor="middle" fontSize="4.5" fill={C.spaceCadet}>−</text>
        </g>
      ))}
      {/* M shell */}
      {[[101, 55], [55, 9], [9, 55], [78, 23]].map(([x, y], i) => (
        <g key={`m${i}`}>
          <circle cx={x} cy={y} r="4.5" fill={C.lavender} />
          <text x={x} y={y + 1.8} textAnchor="middle" fontSize="4.5" fill={C.spaceCadet}>−</text>
        </g>
      ))}
      {/* Shell labels */}
      <text x="71" y="43" fontSize="7" fill={C.ucla} fontFamily="'DM Mono', monospace">K</text>
      <text x="87" y="34" fontSize="7" fill={C.ucla} fontFamily="'DM Mono', monospace">L</text>
      <text x="103" y="32" fontSize="7" fill={C.ucla} fontFamily="'DM Mono', monospace">M</text>
    </svg>
  );
}

function ModernAtom({ size = 110 }: { size?: number }) {
  const cloud = [
    { x: 55, y: 8, r: 2.2, o: 0.35 }, { x: 72, y: 12, r: 2, o: 0.4 }, { x: 88, y: 22, r: 2.5, o: 0.45 },
    { x: 97, y: 38, r: 2, o: 0.4 }, { x: 100, y: 55, r: 2.8, o: 0.45 }, { x: 95, y: 72, r: 2, o: 0.4 },
    { x: 83, y: 86, r: 2.5, o: 0.4 }, { x: 67, y: 96, r: 2, o: 0.45 }, { x: 50, y: 100, r: 2.8, o: 0.4 },
    { x: 32, y: 95, r: 2, o: 0.4 }, { x: 16, y: 84, r: 2.5, o: 0.45 }, { x: 6, y: 68, r: 2, o: 0.4 },
    { x: 4, y: 50, r: 2.8, o: 0.45 }, { x: 10, y: 33, r: 2, o: 0.4 }, { x: 22, y: 18, r: 2.5, o: 0.45 },
    { x: 38, y: 10, r: 2, o: 0.4 },
    { x: 55, y: 20, r: 3, o: 0.62 }, { x: 72, y: 26, r: 2.5, o: 0.65 }, { x: 84, y: 40, r: 3, o: 0.62 },
    { x: 87, y: 56, r: 2.5, o: 0.65 }, { x: 80, y: 70, r: 3, o: 0.62 }, { x: 66, y: 82, r: 2.5, o: 0.65 },
    { x: 50, y: 86, r: 3, o: 0.62 }, { x: 34, y: 80, r: 2.5, o: 0.65 }, { x: 22, y: 68, r: 3, o: 0.62 },
    { x: 17, y: 52, r: 2.5, o: 0.65 }, { x: 24, y: 36, r: 3, o: 0.62 }, { x: 38, y: 24, r: 2.5, o: 0.65 },
    { x: 55, y: 31, r: 3.5, o: 0.82 }, { x: 68, y: 38, r: 3, o: 0.78 }, { x: 74, y: 52, r: 3.5, o: 0.82 },
    { x: 68, y: 67, r: 3, o: 0.78 }, { x: 55, y: 74, r: 3.5, o: 0.82 }, { x: 40, y: 67, r: 3, o: 0.78 },
    { x: 35, y: 52, r: 3.5, o: 0.82 }, { x: 40, y: 38, r: 3, o: 0.78 },
    { x: 55, y: 41, r: 4, o: 0.95 }, { x: 65, y: 52, r: 3.5, o: 0.9 }, { x: 55, y: 64, r: 4, o: 0.95 },
    { x: 44, y: 52, r: 3.5, o: 0.9 }, { x: 60, y: 46, r: 3, o: 1 }, { x: 50, y: 62, r: 3, o: 1 },
  ];
  return (
    <svg viewBox="0 0 110 110" width={size} height={size}>
      {cloud.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r={d.r} fill={C.lavender} opacity={d.o} />
      ))}
      <circle cx="55" cy="55" r="10" fill={C.spaceCadet} />
      <text x="55" y="58.5" textAnchor="middle" fontSize="6" fill={C.air} fontWeight="bold">N+</text>
    </svg>
  );
}

function CoverAtom() {
  return (
    <svg viewBox="0 0 220 220" className="w-full h-full" style={{ overflow: "visible" }}>
      <style>{`
        @keyframes spin1 { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes spin2 { from { transform: rotate(120deg); } to { transform: rotate(480deg); } }
        @keyframes spin3 { from { transform: rotate(240deg); } to { transform: rotate(600deg); } }
        @keyframes spin1r { from { transform: rotate(0deg); } to { transform: rotate(-360deg); } }
        @keyframes spin2r { from { transform: rotate(120deg); } to { transform: rotate(-240deg); } }
        @keyframes spin3r { from { transform: rotate(240deg); } to { transform: rotate(-120deg); } }
        .orbit-ring { fill: none; stroke-width: 1.5; opacity: 0.45; }
        .e-dot { r: 7; }
      `}</style>
      <defs>
        <radialGradient id="nucG" cx="35%" cy="28%">
          <stop offset="0%" stopColor={C.air} />
          <stop offset="60%" stopColor={C.azure} />
          <stop offset="100%" stopColor={C.spaceCadet} />
        </radialGradient>
        <radialGradient id="eG" cx="35%" cy="35%">
          <stop offset="0%" stopColor="#EDD8F5" />
          <stop offset="100%" stopColor={C.lavender} />
        </radialGradient>
      </defs>
      {/* Orbital ellipses — static reference rings */}
      <ellipse cx="110" cy="110" rx="88" ry="32" className="orbit-ring" stroke={C.azure} transform="rotate(-30 110 110)" />
      <ellipse cx="110" cy="110" rx="88" ry="32" className="orbit-ring" stroke={C.azure} transform="rotate(30 110 110)" />
      <ellipse cx="110" cy="110" rx="88" ry="32" className="orbit-ring" stroke={C.azure} />
      {/* Nucleus */}
      <circle cx="110" cy="110" r="22" fill="url(#nucG)" />
      <circle cx="103" cy="104" r="7" fill={C.lavender} opacity="0.9" />
      <circle cx="117" cy="104" r="7" fill={C.lavender} opacity="0.9" />
      <circle cx="110" cy="118" r="7" fill={C.ucla} opacity="0.9" />
      <text x="103" y="106.5" textAnchor="middle" fontSize="7" fill={C.spaceCadet} fontWeight="bold">+</text>
      <text x="117" y="106.5" textAnchor="middle" fontSize="7" fill={C.spaceCadet} fontWeight="bold">+</text>
      <text x="110" y="120.5" textAnchor="middle" fontSize="7" fill="white">0</text>
      {/* Orbiting electrons — three groups rotating around nucleus center */}
      <g style={{ transformOrigin: "110px 110px", animation: "spin1 3.6s linear infinite" }}>
        <circle cx="198" cy="110" r="8" fill="url(#eG)" />
        <text x="198" y="113" textAnchor="middle" fontSize="8" fill={C.spaceCadet} style={{ pointerEvents: "none" }}>−</text>
      </g>
      <g style={{ transformOrigin: "110px 110px", animation: "spin2 3.6s linear infinite" }}>
        <circle cx="198" cy="110" r="8" fill="url(#eG)" />
        <text x="198" y="113" textAnchor="middle" fontSize="8" fill={C.spaceCadet} style={{ pointerEvents: "none" }}>−</text>
      </g>
      <g style={{ transformOrigin: "110px 110px", animation: "spin3 3.6s linear infinite" }}>
        <circle cx="198" cy="110" r="8" fill="url(#eG)" />
        <text x="198" y="113" textAnchor="middle" fontSize="8" fill={C.spaceCadet} style={{ pointerEvents: "none" }}>−</text>
      </g>
    </svg>
  );
}

function ElectronShellDiagram() {
  const shells = [
    { r: 18, label: "K", electrons: [[55, 37]], max: 2 },
    { r: 32, label: "L", electrons: [[55, 23], [87, 55], [55, 87], [23, 55]], max: 8 },
    { r: 46, label: "M", electrons: [[55, 9], [93, 26], [100, 64], [74, 97], [36, 97], [10, 64], [17, 26]], max: 18 },
    { r: 60, label: "N", electrons: [[55, -5]], max: 32 },
  ];
  return (
    <svg viewBox="0 0 110 110" className="w-full h-full">
      {shells.map((s) => (
        <circle key={s.label} cx="55" cy="55" r={s.r} fill="none" stroke={C.air} strokeWidth="1.1" opacity="0.7" />
      ))}
      <circle cx="55" cy="55" r="10" fill={C.spaceCadet} />
      <text x="55" y="58.5" textAnchor="middle" fontSize="6" fill={C.lavender} fontWeight="bold">N</text>
      {/* K shell electron */}
      <circle cx="55" cy="37" r="4" fill={C.lavender} />
      <text x="55" y="38.5" textAnchor="middle" fontSize="4" fill={C.spaceCadet}>−</text>
      {/* L shell electrons */}
      {[[55, 23], [87, 55], [55, 87], [23, 55]].map(([x, y], i) => (
        <g key={`le${i}`}>
          <circle cx={x} cy={y} r="4" fill={C.azure} />
          <text x={x} y={y + 1.5} textAnchor="middle" fontSize="4" fill="white">−</text>
        </g>
      ))}
      {/* M shell electrons */}
      {[[55, 9], [93, 27], [101, 64], [74, 98], [36, 98], [17, 64], [17, 27]].map(([x, y], i) => (
        <g key={`me${i}`}>
          <circle cx={x} cy={y} r="3.5" fill={C.ucla} />
          <text x={x} y={y + 1.5} textAnchor="middle" fontSize="3.5" fill="white">−</text>
        </g>
      ))}
      {/* Shell labels */}
      <text x="73" y="41" fontSize="6.5" fill={C.spaceCadet} fontFamily="'DM Mono', monospace" fontWeight="bold">K</text>
      <text x="89" y="32" fontSize="6.5" fill={C.spaceCadet} fontFamily="'DM Mono', monospace" fontWeight="bold">L</text>
      <text x="104" y="22" fontSize="6.5" fill={C.spaceCadet} fontFamily="'DM Mono', monospace" fontWeight="bold">M</text>
    </svg>
  );
}

function ElementNotation({
  symbol,
  mass,
  atomic,
}: {
  symbol: string;
  mass: number;
  atomic: number;
}) {
  return (
    <svg viewBox="0 0 90 90" className="w-full h-full">
      <rect x="5" y="5" width="80" height="80" rx="6" fill="white" stroke={C.azure} strokeWidth="2" />
      <text
        x="45"
        y="58"
        textAnchor="middle"
        fontSize="40"
        fill={C.spaceCadet}
        fontFamily="'Fraunces', serif"
        fontWeight="700"
      >
        {symbol}
      </text>
      <text
        x="18"
        y="34"
        textAnchor="middle"
        fontSize="15"
        fill={C.azure}
        fontFamily="'DM Mono', monospace"
        fontWeight="500"
      >
        {mass}
      </text>
      <text
        x="18"
        y="72"
        textAnchor="middle"
        fontSize="15"
        fill={C.lavender}
        fontFamily="'DM Mono', monospace"
        fontWeight="500"
        style={{ fill: C.ucla }}
      >
        {atomic}
      </text>
    </svg>
  );
}

// ─── Page 1 — Cover ────────────────────────────────────────────────────────────
function CoverPage({ onNav }: { onNav: (i: number) => void }) {
  return (
    <section
      id="page-1"
      className="relative min-h-screen flex flex-col overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      {/* Top accent stripe */}
      <div
        className="h-2 w-full"
        style={{
          background: `linear-gradient(90deg, ${C.spaceCadet}, ${C.azure}, ${C.air}, ${C.lavender})`,
        }}
      />
      <div className="relative z-10 flex flex-col items-center justify-center flex-1 px-6 py-12">
        {/* Course badge */}
        <div className="mb-6 flex items-center gap-2">
          <TagBadge color={C.ucla}>CHEMISTRY</TagBadge>
          <TagBadge color={C.azure}>UNIT 1</TagBadge>
          <TagBadge color={C.lavender}>STUDY GUIDE</TagBadge>
        </div>
        {/* Title */}
        <h1
          className="text-center leading-none mb-2"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(2.6rem, 7vw, 5.2rem)",
            fontWeight: 800,
            color: C.spaceCadet,
            letterSpacing: "-0.02em",
          }}
        >
          Atomic
        </h1>
        <h1
          className="text-center leading-none mb-4"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(2.6rem, 7vw, 5.2rem)",
            fontWeight: 300,
            color: C.azure,
            letterSpacing: "-0.02em",
          }}
        >
          Structure
        </h1>
        <p
          className="text-center text-sm tracking-widest uppercase mb-8 opacity-70"
          style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}
        >
          The Study of Atoms: Composition, Structure & Behaviour
        </p>

        {/* Atom diagram */}
        <div className="w-64 h-64 md:w-80 md:h-80 mb-8">
          <CoverAtom />
        </div>

        {/* Info grid */}
        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-xl mb-10"
        >
          {[
            { label: "Pages", value: "7" },
            { label: "Scientists", value: "5" },
            { label: "Models", value: "5" },
            { label: "Subject", value: "Chem" },
          ].map((item) => (
            <div
              key={item.label}
              className="rounded-xl px-3 py-4 text-center"
              style={{ backgroundColor: "white", border: `1px solid ${C.azure}28` }}
            >
              <div
                className="text-2xl font-bold"
                style={{ fontFamily: "'Fraunces', serif", color: C.azure }}
              >
                {item.value}
              </div>
              <div
                className="text-xs tracking-widest uppercase opacity-60"
                style={{ color: C.spaceCadet, fontFamily: "'DM Mono', monospace" }}
              >
                {item.label}
              </div>
            </div>
          ))}
        </div>

        {/* Contents preview */}
        <div
          className="w-full max-w-xl rounded-2xl p-5"
          style={{ backgroundColor: "white", border: `1px solid ${C.azure}28` }}
        >
          <div
            className="text-xs font-bold tracking-widest mb-3"
            style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}
          >
            CONTENTS
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {[
              [1, "What is an Atom?"],
              [2, "Subatomic Particles"],
              [3, "Atomic Models Pt. I"],
              [4, "Atomic Models Pt. II"],
              [5, "Electron Shells"],
              [6, "Atomic Number & Isotopes"],
              [7, "Common Mishaps"],
            ].map(([n, title]) => (
              <button
                key={n}
                onClick={() => onNav(Number(n))}
                className="flex items-center gap-2.5 text-left rounded-lg px-3 py-2 text-sm transition-all hover:scale-[1.01]"
                style={{
                  backgroundColor: `${C.azure}10`,
                  color: C.spaceCadet,
                  fontFamily: "'Nunito', sans-serif",
                }}
              >
                <span
                  className="flex-shrink-0 w-5 h-5 rounded-full text-xs flex items-center justify-center font-bold"
                  style={{ backgroundColor: C.azure, color: "white" }}
                >
                  {n}
                </span>
                {title}
              </button>
            ))}
          </div>
        </div>
      </div>
      <PageNumber n={1} />
    </section>
  );
}

// ─── Page 2 — What is an Atom? ─────────────────────────────────────────────────
function Page2() {
  return (
    <section
      id="page-2"
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      <div
        className="h-1 w-full"
        style={{ background: `linear-gradient(90deg, ${C.azure}, ${C.lavender})` }}
      />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <SectionLabel>Page 2 · Introduction</SectionLabel>
            <h2
              style={{
                fontFamily: "'Fraunces', serif",
                fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
                fontWeight: 700,
                color: C.spaceCadet,
                lineHeight: 1.15,
              }}
            >
              What is an Atom?
            </h2>
          </div>
          <div className="w-28 h-28 hidden sm:block">
            <BohrAtom size={112} />
          </div>
        </div>

        {/* Cornell method layout */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{ border: `1.5px solid ${C.azure}30` }}
        >
          {/* Column headers */}
          <div className="grid grid-cols-3 text-xs font-bold tracking-widest"
            style={{ fontFamily: "'DM Mono', monospace" }}>
            <div
              className="px-4 py-2"
              style={{ backgroundColor: C.spaceCadet, color: C.lavender }}
            >
              CUES / QUESTIONS
            </div>
            <div
              className="px-4 py-2 col-span-2"
              style={{ backgroundColor: C.azure, color: "white" }}
            >
              NOTES
            </div>
          </div>

          {/* Cornell rows */}
          {[
            {
              cue: "What is an atom?",
              note: "The atom is the smallest particle of an element that retains the chemical properties of that element. Atoms are the basic building blocks of all matter.",
            },
            {
              cue: "What makes up an atom?",
              note: "ATOM = NUCLEUS + ELECTRONS. The nucleus sits at the centre and contains protons (+) and neutrons (0). Electrons (−) revolve around the nucleus in fixed energy levels called shells.",
            },
            {
              cue: "How small is an atom?",
              note: "Atoms are incredibly tiny — about 1 × 10⁻¹⁰ metres (0.1 nanometres) in diameter. Most of the atom is actually empty space. The nucleus is very small but extremely dense.",
            },
            {
              cue: "Why do elements differ?",
              note: "Each element has a unique number of protons (its atomic number). The number of protons defines what element it is — change the protons and you change the element entirely.",
            },
          ].map((row, i) => (
            <div
              key={i}
              className="grid grid-cols-3 border-t"
              style={{ borderColor: `${C.azure}25` }}
            >
              <div
                className="px-4 py-3 text-sm font-bold leading-snug"
                style={{
                  backgroundColor: `${C.spaceCadet}08`,
                  color: C.spaceCadet,
                  borderRight: `1.5px solid ${C.azure}25`,
                  fontFamily: "'Nunito', sans-serif",
                }}
              >
                {row.cue}
              </div>
              <div
                className="px-4 py-3 text-sm leading-relaxed col-span-2"
                style={{
                  backgroundColor: "white",
                  color: C.spaceCadet,
                  fontFamily: "'Nunito', sans-serif",
                }}
              >
                {row.note}
              </div>
            </div>
          ))}

          {/* Summary row */}
          <div
            className="px-4 py-3 border-t"
            style={{
              borderColor: `${C.azure}25`,
              backgroundColor: `${C.lavender}22`,
            }}
          >
            <div
              className="text-xs font-bold tracking-widest mb-1"
              style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}
            >
              SUMMARY
            </div>
            <p
              className="text-sm leading-relaxed"
              style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}
            >
              An atom is the smallest unit of an element, composed of a dense nucleus (protons + neutrons) surrounded by electrons in shells. Protons define the element; neutrons affect isotopes; electrons drive chemical reactions.
            </p>
          </div>
        </div>

        <Divider />

        {/* Three particle callout boxes */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-2">
          {[
            {
              name: "Electron",
              symbol: "e⁻",
              charge: "−1",
              mass: "0.00055 u",
              location: "Around nucleus",
              color: C.lavender,
              desc: "Negatively charged particle responsible for chemical bonding. Moves around the nucleus in energy levels.",
            },
            {
              name: "Proton",
              symbol: "p⁺",
              charge: "+1",
              mass: "1.007 u",
              location: "Nucleus",
              color: C.azure,
              desc: "Positively charged particle in the nucleus. The number of protons defines the element (atomic number Z).",
            },
            {
              name: "Neutron",
              symbol: "n⁰",
              charge: "0",
              mass: "1.009 u",
              location: "Nucleus",
              color: C.ucla,
              desc: "Neutral particle in the nucleus. Neutrons add mass and stability. Varying neutron numbers create isotopes.",
            },
          ].map((p) => (
            <div
              key={p.name}
              className="rounded-xl p-4"
              style={{
                backgroundColor: "white",
                border: `2px solid ${p.color}50`,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm"
                  style={{
                    backgroundColor: p.color,
                    color: p.name === "Proton" ? "white" : C.spaceCadet,
                    fontFamily: "'DM Mono', monospace",
                  }}
                >
                  {p.symbol}
                </div>
                <span
                  className="font-bold text-base"
                  style={{
                    color: C.spaceCadet,
                    fontFamily: "'Nunito', sans-serif",
                  }}
                >
                  {p.name}
                </span>
              </div>
              <div className="space-y-1 mb-2">
                {[
                  ["Charge", p.charge],
                  ["Mass", p.mass],
                  ["Location", p.location],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between text-xs" style={{ fontFamily: "'DM Mono', monospace" }}>
                    <span style={{ color: C.ucla }}>{k}</span>
                    <span className="font-medium" style={{ color: C.spaceCadet }}>{v}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs leading-relaxed" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                {p.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-4">
          <Box type="remember">
            Atoms are electrically neutral because the number of protons equals the number of electrons. When electrons are gained or lost, the atom becomes an <strong>ion</strong>.
          </Box>
        </div>
      </div>
      <PageNumber n={2} />
    </section>
  );
}

// ─── Page 3 — Subatomic Particles Table ────────────────────────────────────────
function Page3() {
  return (
    <section
      id="page-3"
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      <div
        className="h-1 w-full"
        style={{ background: `linear-gradient(90deg, ${C.lavender}, ${C.azure})` }}
      />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-10">
        <SectionLabel>Page 3</SectionLabel>
        <h2
          className="mb-6"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
            fontWeight: 700,
            color: C.spaceCadet,
          }}
        >
          Subatomic Particles
        </h2>

        {/* Main particles table */}
        <div
          className="rounded-2xl overflow-hidden mb-6"
          style={{ border: `1.5px solid ${C.azure}30` }}
        >
          <div
            className="grid text-xs font-bold tracking-widest py-2.5 px-4"
            style={{
              gridTemplateColumns: "1fr 1fr 1.2fr 1fr 1.5fr",
              backgroundColor: C.spaceCadet,
              color: C.lavender,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            <span>PARTICLE</span>
            <span>CHARGE</span>
            <span>LOCATION</span>
            <span>MASS (u)</span>
            <span>DISCOVERED BY</span>
          </div>
          {[
            {
              name: "Proton",
              charge: "+1",
              location: "Nucleus",
              mass: "1.00728",
              by: "Rutherford (1917)",
              color: C.azure,
            },
            {
              name: "Neutron",
              charge: "0",
              location: "Nucleus",
              mass: "1.00867",
              by: "Chadwick (1932)",
              color: C.ucla,
            },
            {
              name: "Electron",
              charge: "−1",
              location: "Around nucleus",
              mass: "0.000549",
              by: "J.J. Thomson (1897)",
              color: C.lavender,
            },
          ].map((row, i) => (
            <div
              key={row.name}
              className="grid items-center py-3 px-4 border-t text-sm"
              style={{
                gridTemplateColumns: "1fr 1fr 1.2fr 1fr 1.5fr",
                borderColor: `${C.azure}20`,
                backgroundColor: i % 2 === 0 ? "white" : `${C.azure}06`,
                fontFamily: "'Nunito', sans-serif",
                color: C.spaceCadet,
              }}
            >
              <span className="flex items-center gap-2 font-bold">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: row.color }}
                />
                {row.name}
              </span>
              <span
                className="font-bold"
                style={{
                  color:
                    row.charge === "+1"
                      ? C.azure
                      : row.charge === "−1"
                      ? "#8B3A6A"
                      : C.ucla,
                  fontFamily: "'DM Mono', monospace",
                }}
              >
                {row.charge}
              </span>
              <span>{row.location}</span>
              <span style={{ fontFamily: "'DM Mono', monospace" }}>{row.mass}</span>
              <span className="text-xs" style={{ color: C.ucla }}>{row.by}</span>
            </div>
          ))}
        </div>

        {/* Visual particle comparison */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          {[
            { label: "PROTON", symbol: "+", color: C.azure, detail: "Found in all nuclei. Atomic number = proton count." },
            { label: "NEUTRON", symbol: "0", color: C.ucla, detail: "No charge. Adds mass, stabilises the nucleus." },
            { label: "ELECTRON", symbol: "−", color: "#9E5C9A", detail: "Barely any mass. Determines reactivity & bonding." },
          ].map((p) => (
            <div
              key={p.label}
              className="rounded-2xl p-4 flex flex-col items-center text-center gap-2"
              style={{ backgroundColor: "white", border: `1.5px solid ${p.color}45` }}
            >
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold"
                style={{ backgroundColor: `${p.color}22`, border: `2px solid ${p.color}`, color: p.color }}
              >
                {p.symbol}
              </div>
              <div
                className="text-xs font-bold tracking-widest"
                style={{ color: p.color, fontFamily: "'DM Mono', monospace" }}
              >
                {p.label}
              </div>
              <p className="text-xs leading-relaxed" style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}>
                {p.detail}
              </p>
            </div>
          ))}
        </div>

        <Divider />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Box type="key" title="RELATIVE MASSES">
              <ul className="space-y-1">
                <li>Proton ≈ Neutron ≈ <strong>1 u</strong> (atomic mass unit)</li>
                <li>Electron ≈ <strong>1/1836</strong> of a proton — practically negligible</li>
                <li>Almost all mass is concentrated in the tiny nucleus</li>
              </ul>
            </Box>
            <Box type="formula" title="MASS NUMBER FORMULA">
              <p className="font-mono text-base">A = Z + N</p>
              <p className="mt-1 text-xs">where A = mass number, Z = protons, N = neutrons</p>
            </Box>
          </div>
          <div>
            <Box type="remember" title="KEY RELATIONSHIPS">
              <ul className="space-y-1">
                <li>In a <strong>neutral atom</strong>: protons = electrons</li>
                <li>In a <strong>positive ion</strong>: protons &gt; electrons (lost e⁻)</li>
                <li>In a <strong>negative ion</strong>: electrons &gt; protons (gained e⁻)</li>
                <li>Neutrons = Mass Number − Atomic Number</li>
              </ul>
            </Box>
            <Box type="info" title="JAMES CHADWICK — 1932">
              Discovered the neutron by bombarding beryllium with alpha particles. His discovery completed the model of the nucleus and explained isotopes.
            </Box>
          </div>
        </div>
      </div>
      <PageNumber n={3} />
    </section>
  );
}

// ─── Page 4 — Atomic Models Part I (Dalton, Thomson, Rutherford) ──────────────
function Page4() {
  const models = [
    {
      year: "1803",
      scientist: "John Dalton",
      name: "Solid Sphere / Billiard Ball Model",
      diagram: <DaltonAtom size={100} />,
      proposed: [
        "All matter is made of tiny, indivisible particles called atoms",
        "Atoms of the same element are identical in mass and properties",
        "Atoms of different elements have different masses",
        "Atoms combine in whole-number ratios to form compounds",
        "Atoms cannot be created, destroyed, or subdivided",
      ],
      wrong: [
        "Atoms are NOT indivisible — they contain subatomic particles",
        "Atoms of the same element can have different masses (isotopes)",
        "Atoms can be split in nuclear reactions",
      ],
      experiment: "Studied gas laws and chemical combining ratios",
      color: C.spaceCadet,
    },
    {
      year: "1897",
      scientist: "J.J. Thomson",
      name: "Plum Pudding Model",
      diagram: <ThomsonAtom size={100} />,
      proposed: [
        "Atom is a sphere of positive charge (the 'pudding')",
        "Electrons are embedded throughout the positive sphere like 'plums'",
        "Discovered the electron using cathode ray tube experiments",
        "First evidence that atoms contain smaller particles",
      ],
      wrong: [
        "Positive charge is NOT spread uniformly — it is concentrated in a tiny nucleus",
        "Electrons do NOT sit still embedded in the atom",
        "No mention of the nucleus",
      ],
      experiment: "Cathode ray tube experiment — deflected rays with electric & magnetic fields, measuring charge-to-mass ratio of electrons",
      color: C.lavender,
    },
    {
      year: "1911",
      scientist: "Ernest Rutherford",
      name: "Nuclear / Planetary Model",
      diagram: <RutherfordAtom size={100} />,
      proposed: [
        "Atom has a small, dense, positively charged nucleus at the centre",
        "Electrons orbit the nucleus at a large distance (like planets around the sun)",
        "Most of the atom is empty space",
        "The nucleus contains all the positive charge",
      ],
      wrong: [
        "Electrons orbiting in circles should radiate energy and spiral into the nucleus",
        "Cannot explain the stability of atoms",
        "Cannot explain atomic spectra (discrete spectral lines)",
        "Electrons don't actually orbit like planets",
      ],
      experiment: "Gold foil experiment (Geiger-Marsden, 1909) — fired alpha particles at thin gold foil; most passed through but some deflected at large angles, even bounced back",
      color: C.azure,
    },
  ];

  return (
    <section
      id="page-4"
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      <div
        className="h-1 w-full"
        style={{ background: `linear-gradient(90deg, ${C.azure}, ${C.spaceCadet})` }}
      />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-10">
        <SectionLabel>Page 4</SectionLabel>
        <h2
          className="mb-2"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
            fontWeight: 700,
            color: C.spaceCadet,
          }}
        >
          Atomic Models — Part I
        </h2>
        <p
          className="text-sm mb-6 opacity-70"
          style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}
        >
          Dalton · Thomson · Rutherford — how our understanding evolved (1803–1911)
        </p>

        {/* Timeline connector */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
          {models.map((m, i) => (
            <div key={m.year} className="flex items-center gap-2 flex-shrink-0">
              <div
                className="flex flex-col items-center"
                style={{ fontFamily: "'DM Mono', monospace" }}
              >
                <div
                  className="text-xs font-bold px-3 py-1 rounded-full"
                  style={{ backgroundColor: m.color, color: "white" }}
                >
                  {m.year}
                </div>
                <div className="text-xs mt-1 font-bold" style={{ color: C.spaceCadet }}>
                  {m.scientist.split(" ")[1]}
                </div>
              </div>
              {i < models.length - 1 && (
                <div
                  className="h-px w-12 flex-shrink-0"
                  style={{ backgroundColor: `${C.azure}45` }}
                />
              )}
            </div>
          ))}
          <div
            className="h-px flex-1"
            style={{ backgroundColor: `${C.azure}30` }}
          />
          <div
            className="text-xs px-2 py-1 rounded-full flex-shrink-0"
            style={{
              backgroundColor: `${C.azure}18`,
              color: C.azure,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            → continued on next page
          </div>
        </div>

        <div className="space-y-5">
          {models.map((m) => (
            <div
              key={m.year}
              className="rounded-2xl overflow-hidden"
              style={{ backgroundColor: "white", border: `1.5px solid ${m.color}40` }}
            >
              {/* Model header */}
              <div
                className="px-5 py-3 flex items-center justify-between"
                style={{ backgroundColor: `${m.color}15`, borderBottom: `1px solid ${m.color}25` }}
              >
                <div className="flex items-center gap-3">
                  <span
                    className="text-xs font-bold tracking-widest px-2 py-0.5 rounded-full"
                    style={{
                      backgroundColor: m.color,
                      color: "white",
                      fontFamily: "'DM Mono', monospace",
                    }}
                  >
                    {m.year}
                  </span>
                  <div>
                    <div
                      className="font-bold text-base"
                      style={{
                        color: C.spaceCadet,
                        fontFamily: "'Fraunces', serif",
                      }}
                    >
                      {m.scientist}
                    </div>
                    <div
                      className="text-xs opacity-70"
                      style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}
                    >
                      {m.name}
                    </div>
                  </div>
                </div>
              </div>

              {/* Model body */}
              <div className="p-5 grid grid-cols-1 sm:grid-cols-5 gap-5">
                {/* Diagram */}
                <div className="sm:col-span-1 flex flex-col items-center justify-start gap-2">
                  <div className="w-24 h-24">{m.diagram}</div>
                  <div
                    className="text-xs text-center opacity-60"
                    style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}
                  >
                    {m.name}
                  </div>
                </div>

                {/* Content */}
                <div className="sm:col-span-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <div
                      className="text-xs font-bold tracking-widest mb-2"
                      style={{ color: m.color, fontFamily: "'DM Mono', monospace" }}
                    >
                      ✓ PROPOSED
                    </div>
                    <ul className="space-y-1">
                      {m.proposed.map((p, i) => (
                        <BulletItem key={i} color={m.color}>
                          {p}
                        </BulletItem>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div
                      className="text-xs font-bold tracking-widest mb-2"
                      style={{ color: "#C04040", fontFamily: "'DM Mono', monospace" }}
                    >
                      ✕ LIMITATIONS
                    </div>
                    <ul className="space-y-1">
                      {m.wrong.map((w, i) => (
                        <BulletItem key={i} color="#C04040">
                          {w}
                        </BulletItem>
                      ))}
                    </ul>
                    <div
                      className="mt-3 rounded-lg p-2.5 text-xs leading-relaxed"
                      style={{
                        backgroundColor: `${m.color}12`,
                        color: C.spaceCadet,
                        fontFamily: "'Nunito', sans-serif",
                        borderLeft: `2px solid ${m.color}`,
                      }}
                    >
                      <span
                        className="font-bold"
                        style={{ color: m.color, fontFamily: "'DM Mono', monospace" }}
                      >
                        KEY EXPERIMENT:{" "}
                      </span>
                      {m.experiment}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <PageNumber n={4} />
    </section>
  );
}

// ─── Page 5 — Atomic Models Part II (Bohr + Modern) ───────────────────────────
function Page5() {
  return (
    <section
      id="page-5"
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      <div
        className="h-1 w-full"
        style={{ background: `linear-gradient(90deg, ${C.spaceCadet}, ${C.air})` }}
      />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-10">
        <SectionLabel>Page 5</SectionLabel>
        <h2
          className="mb-2"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
            fontWeight: 700,
            color: C.spaceCadet,
          }}
        >
          Atomic Models — Part II
        </h2>
        <p
          className="text-sm mb-6 opacity-70"
          style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}
        >
          Bohr · Modern Quantum Model — how quantum mechanics changed everything (1913–present)
        </p>

        {/* Bohr */}
        <div
          className="rounded-2xl overflow-hidden mb-5"
          style={{ backgroundColor: "white", border: `1.5px solid ${C.azure}40` }}
        >
          <div
            className="px-5 py-3 flex items-center gap-3"
            style={{
              backgroundColor: `${C.azure}15`,
              borderBottom: `1px solid ${C.azure}25`,
            }}
          >
            <span
              className="text-xs font-bold tracking-widest px-2 py-0.5 rounded-full"
              style={{ backgroundColor: C.azure, color: "white", fontFamily: "'DM Mono', monospace" }}
            >
              1913
            </span>
            <div>
              <div
                className="font-bold text-base"
                style={{ color: C.spaceCadet, fontFamily: "'Fraunces', serif" }}
              >
                Niels Bohr
              </div>
              <div className="text-xs opacity-70" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                Planetary / Bohr Model
              </div>
            </div>
          </div>
          <div className="p-5 grid grid-cols-1 sm:grid-cols-5 gap-5">
            <div className="sm:col-span-1 flex flex-col items-center gap-2">
              <div className="w-28 h-28">
                <BohrAtom size={112} />
              </div>
              <div className="text-xs text-center opacity-60" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                Fixed circular orbits
              </div>
            </div>
            <div className="sm:col-span-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="text-xs font-bold tracking-widest mb-2" style={{ color: C.azure, fontFamily: "'DM Mono', monospace" }}>✓ PROPOSED</div>
                <ul className="space-y-1">
                  {[
                    "Electrons orbit the nucleus in specific, fixed energy levels (shells)",
                    "Electrons in a given orbit have a fixed energy — they do not radiate energy",
                    "Electrons can jump to higher orbits by absorbing energy (photons)",
                    "Electrons fall back emitting light of specific wavelengths (atomic spectra)",
                    "Each shell has a maximum number of electrons it can hold",
                    "Successfully explained hydrogen's spectral lines",
                  ].map((p, i) => (
                    <BulletItem key={i} color={C.azure}>{p}</BulletItem>
                  ))}
                </ul>
              </div>
              <div>
                <div className="text-xs font-bold tracking-widest mb-2" style={{ color: "#C04040", fontFamily: "'DM Mono', monospace" }}>✕ LIMITATIONS</div>
                <ul className="space-y-1">
                  {[
                    "Only works accurately for hydrogen (one electron)",
                    "Electrons don't actually follow defined circular paths",
                    "Cannot explain fine spectral lines (Zeeman effect)",
                    "Does not account for quantum mechanical behaviour",
                  ].map((w, i) => (
                    <BulletItem key={i} color="#C04040">{w}</BulletItem>
                  ))}
                </ul>
                <div
                  className="mt-3 rounded-lg p-2.5 text-xs leading-relaxed"
                  style={{ backgroundColor: `${C.azure}12`, color: C.spaceCadet, fontFamily: "'Nunito', sans-serif", borderLeft: `2px solid ${C.azure}` }}
                >
                  <span className="font-bold" style={{ color: C.azure, fontFamily: "'DM Mono', monospace" }}>KEY EXPERIMENT: </span>
                  Studied hydrogen emission spectrum — explained why hydrogen emits light at specific wavelengths (Balmer series), matching his energy-level calculations precisely.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modern Model */}
        <div
          className="rounded-2xl overflow-hidden mb-6"
          style={{ backgroundColor: "white", border: `1.5px solid ${C.air}40` }}
        >
          <div
            className="px-5 py-3 flex items-center gap-3"
            style={{ backgroundColor: `${C.air}18`, borderBottom: `1px solid ${C.air}25` }}
          >
            <span
              className="text-xs font-bold tracking-widest px-2 py-0.5 rounded-full"
              style={{ backgroundColor: C.air, color: "white", fontFamily: "'DM Mono', monospace" }}
            >
              1926+
            </span>
            <div>
              <div className="font-bold text-base" style={{ color: C.spaceCadet, fontFamily: "'Fraunces', serif" }}>
                Modern Quantum Mechanical Model
              </div>
              <div className="text-xs opacity-70" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                Schrödinger · Heisenberg · de Broglie · Pauli
              </div>
            </div>
          </div>
          <div className="p-5 grid grid-cols-1 sm:grid-cols-5 gap-5">
            <div className="sm:col-span-1 flex flex-col items-center gap-2">
              <div className="w-28 h-28">
                <ModernAtom size={112} />
              </div>
              <div className="text-xs text-center opacity-60" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                Probability cloud
              </div>
            </div>
            <div className="sm:col-span-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="text-xs font-bold tracking-widest mb-2" style={{ color: C.air, fontFamily: "'DM Mono', monospace" }}>✓ PROPOSED</div>
                <ul className="space-y-1">
                  {[
                    "Electrons exist in probability clouds (orbitals), not fixed orbits",
                    "The Heisenberg Uncertainty Principle: cannot know both position and momentum simultaneously",
                    "Electrons behave as both waves and particles (de Broglie)",
                    "Schrödinger's equation gives probability of finding an electron",
                    "Pauli Exclusion Principle: no two electrons share the same quantum state",
                    "Electron orbitals have different shapes: s, p, d, f",
                  ].map((p, i) => (
                    <BulletItem key={i} color={C.air}>{p}</BulletItem>
                  ))}
                </ul>
              </div>
              <div>
                <Box type="key" title="KEY SCIENTISTS">
                  <ul className="space-y-1 text-xs">
                    <li><strong>Erwin Schrödinger (1926)</strong> — Wave equation for electron probability</li>
                    <li><strong>Werner Heisenberg (1927)</strong> — Uncertainty Principle</li>
                    <li><strong>Louis de Broglie (1924)</strong> — Wave-particle duality</li>
                    <li><strong>Wolfgang Pauli (1925)</strong> — Exclusion Principle</li>
                  </ul>
                </Box>
                <Box type="remember">
                  Denser regions of the electron cloud = higher probability of finding the electron there. The cloud doesn't show where the electron IS — only where it's LIKELY to be.
                </Box>
              </div>
            </div>
          </div>
        </div>

        {/* Comparison table */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{ border: `1.5px solid ${C.azure}30` }}
        >
          <div
            className="px-4 py-2.5 text-xs font-bold tracking-widest"
            style={{ backgroundColor: C.spaceCadet, color: C.lavender, fontFamily: "'DM Mono', monospace" }}
          >
            ALL 5 MODELS AT A GLANCE
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs" style={{ fontFamily: "'Nunito', sans-serif" }}>
              <thead>
                <tr style={{ backgroundColor: `${C.azure}12` }}>
                  {["Scientist", "Year", "Electron Location", "Nucleus", "What was new"].map((h) => (
                    <th key={h} className="px-3 py-2 text-left font-bold" style={{ color: C.spaceCadet }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  ["Dalton", "1803", "Not mentioned", "Not mentioned", "Atoms are indivisible spheres"],
                  ["J.J. Thomson", "1897", "Embedded in positive sphere", "No nucleus concept", "Discovered the electron"],
                  ["Rutherford", "1911", "Orbit at great distance", "Small, dense, positive", "Discovered the nucleus"],
                  ["Bohr", "1913", "Fixed circular orbits (shells)", "Positive, central", "Quantised energy levels"],
                  ["Modern", "1926+", "Probability clouds (orbitals)", "Positive, central", "Quantum mechanics, wave-particle duality"],
                ].map(([sci, yr, el, nuc, news], i) => (
                  <tr
                    key={sci}
                    className="border-t"
                    style={{
                      borderColor: `${C.azure}15`,
                      backgroundColor: i % 2 === 0 ? "white" : `${C.azure}05`,
                    }}
                  >
                    <td className="px-3 py-2 font-bold" style={{ color: C.spaceCadet }}>{sci}</td>
                    <td className="px-3 py-2" style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}>{yr}</td>
                    <td className="px-3 py-2" style={{ color: C.spaceCadet }}>{el}</td>
                    <td className="px-3 py-2" style={{ color: C.spaceCadet }}>{nuc}</td>
                    <td className="px-3 py-2" style={{ color: C.azure }}>{news}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <PageNumber n={5} />
    </section>
  );
}

// ─── Page 6 — Electron Shells ──────────────────────────────────────────────────
function Page6() {
  const shells = [
    { label: "K", n: 1, max: 2, formula: "2×1² = 2", color: C.lavender, example: "H, He" },
    { label: "L", n: 2, max: 8, formula: "2×2² = 8", color: C.azure, example: "Li → Ne" },
    { label: "M", n: 3, max: 18, formula: "2×3² = 18", color: C.ucla, example: "Na → Ar" },
    { label: "N", n: 4, max: 32, formula: "2×4² = 32", color: C.air, example: "K → Kr" },
  ];

  return (
    <section
      id="page-6"
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      <div
        className="h-1 w-full"
        style={{ background: `linear-gradient(90deg, ${C.air}, ${C.lavender})` }}
      />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-10">
        <SectionLabel>Page 6</SectionLabel>
        <h2
          className="mb-6"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
            fontWeight: 700,
            color: C.spaceCadet,
          }}
        >
          Electron Shells &amp; Atomic Notation
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
          {/* Shell diagram */}
          <div
            className="rounded-2xl p-6 flex flex-col items-center"
            style={{ backgroundColor: "white", border: `1.5px solid ${C.azure}30` }}
          >
            <div
              className="text-xs font-bold tracking-widest mb-3"
              style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}
            >
              ELECTRON SHELL DIAGRAM
            </div>
            <div className="w-44 h-44">
              <ElectronShellDiagram />
            </div>
            <p
              className="text-xs text-center mt-3 leading-relaxed opacity-70"
              style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}
            >
              Electrons fill shells starting from K (innermost). Each shell has a maximum capacity given by 2n².
            </p>
          </div>

          {/* Shells table */}
          <div>
            <div
              className="rounded-2xl overflow-hidden mb-4"
              style={{ border: `1.5px solid ${C.azure}30` }}
            >
              <div
                className="grid text-xs font-bold tracking-widest py-2 px-3"
                style={{
                  gridTemplateColumns: "0.5fr 0.5fr 1fr 1fr 1fr",
                  backgroundColor: C.spaceCadet,
                  color: C.lavender,
                  fontFamily: "'DM Mono', monospace",
                }}
              >
                <span>Shell</span>
                <span>n</span>
                <span>Max e⁻</span>
                <span>Formula</span>
                <span>Examples</span>
              </div>
              {shells.map((s, i) => (
                <div
                  key={s.label}
                  className="grid items-center py-2.5 px-3 border-t text-sm"
                  style={{
                    gridTemplateColumns: "0.5fr 0.5fr 1fr 1fr 1fr",
                    borderColor: `${C.azure}18`,
                    backgroundColor: i % 2 === 0 ? "white" : `${C.azure}05`,
                    fontFamily: "'Nunito', sans-serif",
                    color: C.spaceCadet,
                  }}
                >
                  <span
                    className="font-bold text-base"
                    style={{ color: s.color, fontFamily: "'DM Mono', monospace" }}
                  >
                    {s.label}
                  </span>
                  <span style={{ fontFamily: "'DM Mono', monospace" }}>{s.n}</span>
                  <span className="font-bold" style={{ fontFamily: "'DM Mono', monospace" }}>
                    {s.max}
                  </span>
                  <span className="text-xs" style={{ fontFamily: "'DM Mono', monospace", color: C.ucla }}>
                    {s.formula}
                  </span>
                  <span className="text-xs" style={{ color: C.ucla }}>{s.example}</span>
                </div>
              ))}
            </div>
            <Box type="formula" title="MAX ELECTRONS PER SHELL">
              <p>Maximum electrons in shell n = <strong>2n²</strong></p>
              <p className="mt-1 text-xs">K: 2×1²=2 · L: 2×2²=8 · M: 2×3²=18 · N: 2×4²=32</p>
            </Box>
          </div>
        </div>

        <Divider />

        {/* Atomic Number & Mass Number */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <div
              className="text-sm font-bold mb-3"
              style={{ color: C.spaceCadet, fontFamily: "'Fraunces', serif" }}
            >
              Atomic Number &amp; Mass Number
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              {[
                { symbol: "C", mass: 12, atomic: 6, name: "Carbon" },
                { symbol: "Na", mass: 23, atomic: 11, name: "Sodium" },
              ].map((el) => (
                <div
                  key={el.symbol}
                  className="rounded-xl p-3 flex flex-col items-center gap-2"
                  style={{ backgroundColor: "white", border: `1.5px solid ${C.azure}30` }}
                >
                  <div className="w-16 h-16">
                    <ElementNotation symbol={el.symbol} mass={el.mass} atomic={el.atomic} />
                  </div>
                  <div className="text-center">
                    <div className="text-xs font-bold" style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}>{el.name}</div>
                    <div className="text-xs" style={{ color: C.azure, fontFamily: "'DM Mono', monospace" }}>
                      {el.atomic}p · {el.mass - el.atomic}n · {el.atomic}e
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Annotation diagram */}
            <div
              className="rounded-xl p-4"
              style={{ backgroundColor: "white", border: `1.5px solid ${C.azure}28` }}
            >
              <div className="flex gap-4 items-center">
                <div className="relative w-20 h-20 flex-shrink-0">
                  <ElementNotation symbol="C" mass={12} atomic={6} />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs" style={{ fontFamily: "'Nunito', sans-serif" }}>
                    <span
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: C.azure, fontSize: "8px" }}
                    >
                      A
                    </span>
                    <span style={{ color: C.spaceCadet }}>
                      <strong>Mass Number (A)</strong> = top left = Protons + Neutrons
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs" style={{ fontFamily: "'Nunito', sans-serif" }}>
                    <span
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: C.ucla, fontSize: "8px" }}
                    >
                      Z
                    </span>
                    <span style={{ color: C.spaceCadet }}>
                      <strong>Atomic Number (Z)</strong> = bottom left = No. of Protons = No. of Electrons
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <div
              className="text-sm font-bold mb-3"
              style={{ color: C.spaceCadet, fontFamily: "'Fraunces', serif" }}
            >
              Isotopes
            </div>
            <Box type="key" title="WHAT ARE ISOTOPES?">
              Isotopes are atoms of the <strong>same element</strong> with the <strong>same number of protons</strong> but a <strong>different number of neutrons</strong> (and therefore different mass numbers).
            </Box>

            {/* Carbon isotopes visual */}
            <div
              className="rounded-xl p-4 mb-3"
              style={{ backgroundColor: "white", border: `1.5px solid ${C.azure}28` }}
            >
              <div
                className="text-xs font-bold tracking-widest mb-3"
                style={{ color: C.ucla, fontFamily: "'DM Mono', monospace" }}
              >
                CARBON ISOTOPES
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { name: "Carbon-12", mass: 12, p: 6, n: 6, stable: true },
                  { name: "Carbon-13", mass: 13, p: 6, n: 7, stable: true },
                  { name: "Carbon-14", mass: 14, p: 6, n: 8, stable: false },
                ].map((iso) => (
                  <div
                    key={iso.name}
                    className="rounded-lg p-2 text-center"
                    style={{ backgroundColor: `${C.azure}08`, border: `1px solid ${C.azure}20` }}
                  >
                    <div
                      className="text-sm font-bold"
                      style={{ color: C.spaceCadet, fontFamily: "'Fraunces', serif" }}
                    >
                      ¹²C
                      <sup
                        style={{
                          fontSize: "0.6em",
                          verticalAlign: "super",
                          color: C.azure,
                          fontFamily: "'DM Mono', monospace",
                          fontWeight: "bold",
                        }}
                      >
                        {iso.mass}
                      </sup>
                    </div>
                    <div className="text-xs mt-1" style={{ color: C.spaceCadet, fontFamily: "'DM Mono', monospace" }}>
                      {iso.p}p · {iso.n}n
                    </div>
                    <div
                      className="text-xs mt-1 font-bold"
                      style={{ color: iso.stable ? "#3A8A5A" : "#C04040" }}
                    >
                      {iso.stable ? "Stable" : "Radioactive"}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Box type="remember">
              <ul className="space-y-1">
                <li>Same atomic number Z → same element</li>
                <li>Same chemical properties (same electrons)</li>
                <li>Different physical properties (different mass)</li>
                <li>C-14 is used in radiocarbon dating</li>
              </ul>
            </Box>
          </div>
        </div>
      </div>
      <PageNumber n={6} />
    </section>
  );
}

// ─── Page 7 — Common Mishaps & Quick Reference ─────────────────────────────────
function Page7() {
  const mishaps = [
    {
      mistake: "Confusing Atomic Number with Mass Number",
      wrong: "Carbon has a mass number of 6",
      correct: "Carbon has an atomic number of 6 (protons) and a mass number of 12 (protons + neutrons)",
    },
    {
      mistake: "Thinking electrons have significant mass",
      wrong: "The mass of an atom equals protons + neutrons + electrons",
      correct: "Electrons are ~1/1836 the mass of a proton. Mass number ignores electrons.",
    },
    {
      mistake: "Assuming Rutherford disproved Thomson completely",
      wrong: "Rutherford's gold foil experiment destroyed Thomson's entire model",
      correct: "Rutherford disproved the plum-pudding structure, but Thomson's discovery of the electron remained foundational.",
    },
    {
      mistake: "Thinking Bohr's model works for all atoms",
      wrong: "Bohr's model accurately describes all elements",
      correct: "Bohr's model only works precisely for hydrogen (1 electron). It fails for multi-electron atoms.",
    },
    {
      mistake: "Saying electrons 'orbit' like planets in the modern model",
      wrong: "Electrons orbit the nucleus in the modern model like planets orbit the sun",
      correct: "In the modern model, electrons exist in probability clouds (orbitals). Their exact position cannot be determined (Heisenberg Uncertainty Principle).",
    },
    {
      mistake: "Confusing isotopes with different elements",
      wrong: "Carbon-12 and Carbon-14 are different elements because they have different masses",
      correct: "They are the same element — both have 6 protons (Z=6). They differ only in neutron count.",
    },
    {
      mistake: "Thinking the nucleus is large",
      wrong: "The nucleus takes up most of the atom's volume",
      correct: "The nucleus is ~100,000 times smaller than the atom. If the atom were a football stadium, the nucleus would be a pea at the centre.",
    },
    {
      mistake: "Mixing up ion types",
      wrong: "A positive ion (cation) has gained electrons",
      correct: "A cation has LOST electrons (fewer electrons than protons). An anion has GAINED electrons.",
    },
  ];

  return (
    <section
      id="page-7"
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: C.paper }}
    >
      <DotPaper />
      <div
        className="h-1 w-full"
        style={{ background: `linear-gradient(90deg, ${C.lavender}, ${C.spaceCadet}, ${C.azure})` }}
      />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-10">
        <SectionLabel>Page 7 · Final</SectionLabel>
        <h2
          className="mb-2"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
            fontWeight: 700,
            color: C.spaceCadet,
          }}
        >
          Common Mishaps &amp; Quick Reference
        </h2>
        <p
          className="text-sm mb-6 opacity-70"
          style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}
        >
          The mistakes students make most — and how to avoid them
        </p>

        {/* Mishaps grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
          {mishaps.map((m, i) => (
            <div
              key={i}
              className="rounded-xl p-4"
              style={{
                backgroundColor: "white",
                border: `1.5px solid ${C.azure}28`,
              }}
            >
              <div
                className="flex items-start gap-2 mb-2"
              >
                <span
                  className="flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5"
                  style={{ backgroundColor: `${C.spaceCadet}15`, color: C.spaceCadet, fontFamily: "'DM Mono', monospace" }}
                >
                  {i + 1}
                </span>
                <div
                  className="text-sm font-bold leading-snug"
                  style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}
                >
                  {m.mistake}
                </div>
              </div>
              <ul className="space-y-1.5 ml-7">
                <CheckItem ok={false}>{m.wrong}</CheckItem>
                <CheckItem ok={true}>{m.correct}</CheckItem>
              </ul>
            </div>
          ))}
        </div>

        <Divider />

        {/* Quick reference */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          {/* Key formulas */}
          <div
            className="rounded-2xl p-4"
            style={{ backgroundColor: "white", border: `1.5px solid ${C.spaceCadet}30` }}
          >
            <div
              className="text-xs font-bold tracking-widest mb-3"
              style={{ color: C.spaceCadet, fontFamily: "'DM Mono', monospace" }}
            >
              KEY FORMULAS
            </div>
            {[
              ["Atomic Number", "Z = no. of protons"],
              ["Mass Number", "A = p + n"],
              ["Neutrons", "N = A − Z"],
              ["Electrons (neutral)", "e⁻ = Z"],
              ["Max electrons", "= 2n²"],
              ["Cation", "e⁻ < Z (lost e⁻)"],
              ["Anion", "e⁻ > Z (gained e⁻)"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex justify-between items-center py-1.5 border-b last:border-0 text-xs"
                style={{ borderColor: `${C.azure}15`, fontFamily: "'DM Mono', monospace" }}
              >
                <span style={{ color: C.ucla }}>{k}</span>
                <span className="font-medium" style={{ color: C.spaceCadet }}>{v}</span>
              </div>
            ))}
          </div>

          {/* Scientists timeline */}
          <div
            className="rounded-2xl p-4"
            style={{ backgroundColor: "white", border: `1.5px solid ${C.azure}30` }}
          >
            <div
              className="text-xs font-bold tracking-widest mb-3"
              style={{ color: C.azure, fontFamily: "'DM Mono', monospace" }}
            >
              SCIENTISTS TIMELINE
            </div>
            <div className="space-y-2">
              {[
                { year: "1803", name: "John Dalton", contrib: "Solid sphere model", color: C.spaceCadet },
                { year: "1897", name: "J.J. Thomson", contrib: "Discovered electron, plum-pudding", color: C.lavender },
                { year: "1909", name: "Geiger & Marsden", contrib: "Gold foil experiment", color: C.air },
                { year: "1911", name: "Ernest Rutherford", contrib: "Nuclear model", color: C.azure },
                { year: "1913", name: "Niels Bohr", contrib: "Fixed electron shells", color: "#5A7A9A" },
                { year: "1924", name: "Louis de Broglie", contrib: "Wave-particle duality", color: C.ucla },
                { year: "1925", name: "Wolfgang Pauli", contrib: "Exclusion Principle", color: C.air },
                { year: "1926", name: "Erwin Schrödinger", contrib: "Wave equation / orbitals", color: C.azure },
                { year: "1927", name: "Werner Heisenberg", contrib: "Uncertainty Principle", color: C.spaceCadet },
                { year: "1932", name: "James Chadwick", contrib: "Discovered neutron", color: C.ucla },
              ].map((s) => (
                <div key={s.year} className="flex items-start gap-2">
                  <span
                    className="text-xs flex-shrink-0 font-bold mt-0.5"
                    style={{ color: s.color, fontFamily: "'DM Mono', monospace", minWidth: "2.8rem" }}
                  >
                    {s.year}
                  </span>
                  <div>
                    <div className="text-xs font-bold leading-none" style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}>
                      {s.name}
                    </div>
                    <div className="text-xs opacity-65" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                      {s.contrib}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mnemonics + summary */}
          <div className="space-y-3">
            <div
              className="rounded-2xl p-4"
              style={{ backgroundColor: "white", border: `1.5px solid ${C.lavender}50` }}
            >
              <div
                className="text-xs font-bold tracking-widest mb-3"
                style={{ color: "#8B5A9A", fontFamily: "'DM Mono', monospace" }}
              >
                MNEMONICS
              </div>
              <div className="space-y-3">
                <div>
                  <div className="text-xs font-bold mb-1" style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}>
                    Electron Shell Filling Order:
                  </div>
                  <div
                    className="text-sm font-bold"
                    style={{ color: C.azure, fontFamily: "'DM Mono', monospace" }}
                  >
                    K → L → M → N
                  </div>
                  <div className="text-xs mt-0.5" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                    "Keep Learning More Neatly"
                  </div>
                </div>
                <div>
                  <div className="text-xs font-bold mb-1" style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}>
                    Subatomic Charge Rule:
                  </div>
                  <div className="text-xs" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                    <strong>P</strong>roton = <strong>P</strong>ositive (+) · <strong>N</strong>eutron = <strong>N</strong>eutral (0) · e<strong>−</strong> = <strong>−</strong>1
                  </div>
                </div>
                <div>
                  <div className="text-xs font-bold mb-1" style={{ color: C.spaceCadet, fontFamily: "'Nunito', sans-serif" }}>
                    Cation vs Anion:
                  </div>
                  <div className="text-xs" style={{ color: C.ucla, fontFamily: "'Nunito', sans-serif" }}>
                    "<strong>C</strong>ation is <strong>C</strong>ut" (lost electrons) — "<strong>An</strong>ion is <strong>An</strong>gry" (gained, negative)
                  </div>
                </div>
              </div>
            </div>

            <div
              className="rounded-2xl p-4"
              style={{ backgroundColor: C.spaceCadet, border: `1.5px solid ${C.spaceCadet}` }}
            >
              <div
                className="text-xs font-bold tracking-widest mb-2"
                style={{ color: C.lavender, fontFamily: "'DM Mono', monospace" }}
              >
                FINAL TRUTH
              </div>
              <p
                className="text-sm leading-relaxed"
                style={{ color: C.air, fontFamily: "'Nunito', sans-serif" }}
              >
                Each atomic model was not "wrong" — each was the best explanation given the technology of its time. Science progresses by{" "}
                <span style={{ color: C.lavender, fontWeight: "bold" }}>
                  building on evidence, correcting errors,
                </span>{" "}
                and refining understanding. The modern model is our{" "}
                <span style={{ color: C.lavender, fontWeight: "bold" }}>
                  best current picture
                </span>{" "}
                — not the last word.
              </p>
            </div>
          </div>
        </div>
      </div>
      <PageNumber n={7} />
    </section>
  );
}

// ─── App Shell ─────────────────────────────────────────────────────────────────
export default function App() {
  const [activePage, setActivePage] = useState(1);

  const pages = [
    { n: 1, label: "Cover" },
    { n: 2, label: "What is an Atom?" },
    { n: 3, label: "Subatomic Particles" },
    { n: 4, label: "Models I" },
    { n: 5, label: "Models II" },
    { n: 6, label: "Shells & Notation" },
    { n: 7, label: "Mishaps & Reference" },
  ];

  const scrollToPage = (n: number) => {
    const el = document.getElementById(`page-${n}`);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
      setActivePage(n);
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            const n = parseInt(id.replace("page-", ""));
            if (!isNaN(n)) setActivePage(n);
          }
        });
      },
      { threshold: 0.4 }
    );

    pages.forEach(({ n }) => {
      const el = document.getElementById(`page-${n}`);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <div
      className="min-h-screen"
      style={{
        fontFamily: "'Nunito', sans-serif",
        scrollBehavior: "smooth",
      }}
    >
      {/* Sticky nav */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-2.5"
        style={{
          backgroundColor: "rgba(244, 247, 252, 0.92)",
          backdropFilter: "blur(12px)",
          borderBottom: `1px solid ${C.azure}22`,
        }}
      >
        <div
          className="text-sm font-bold tracking-tight flex items-center gap-1.5"
          style={{ color: C.spaceCadet, fontFamily: "'Fraunces', serif" }}
        >
          <span style={{ color: C.azure }}>⬡</span>
          Atomic Structure
        </div>
        <div className="flex items-center gap-1 overflow-x-auto max-w-xs sm:max-w-none">
          {pages.map((p) => (
            <button
              key={p.n}
              onClick={() => scrollToPage(p.n)}
              className="flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs transition-all flex-shrink-0"
              style={{
                backgroundColor:
                  activePage === p.n ? C.azure : "transparent",
                color: activePage === p.n ? "white" : C.ucla,
                fontFamily: "'DM Mono', monospace",
                fontWeight: activePage === p.n ? "bold" : "normal",
              }}
            >
              <span
                className="w-4 h-4 rounded-full flex items-center justify-center text-xs"
                style={{
                  backgroundColor:
                    activePage === p.n ? "rgba(255,255,255,0.25)" : `${C.azure}18`,
                  color: activePage === p.n ? "white" : C.azure,
                }}
              >
                {p.n}
              </span>
              <span className="hidden sm:inline">{p.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Pages */}
      <div className="pt-10">
        <CoverPage onNav={scrollToPage} />
        <Page2 />
        <Page3 />
        <Page4 />
        <Page5 />
        <Page6 />
        <Page7 />
      </div>
    </div>
  );
}
