
  # Create Note Template

  This is a code bundle for Create Note Template. The original project is available at https://www.figma.com/design/Vc6Lzeye73Jl6SzRUgqFHQ/Create-Note-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  