
  # Educational Template Design

  This is a code bundle for Educational Template Design. The original project is available at https://www.figma.com/design/2Lpek4crWWyK9MqcdJrFMo/Educational-Template-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  