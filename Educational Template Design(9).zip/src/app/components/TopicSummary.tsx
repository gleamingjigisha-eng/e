import { useState } from "react";
import { BookOpen, Lightbulb, Target, CheckCircle2, Brain, Star } from "lucide-react";

export function TopicSummary() {
  const [topic, setTopic] = useState("Photosynthesis");
  const [overview, setOverview] = useState(
    "The process by which plants convert light energy into chemical energy to fuel their growth."
  );
  const [keyConcepts, setKeyConcepts] = useState([
    { title: "Chlorophyll", description: "Green pigment that absorbs light energy" },
    { title: "Carbon Dioxide", description: "Gas absorbed from the atmosphere" },
    { title: "Water", description: "Absorbed through roots from soil" },
    { title: "Glucose", description: "Sugar produced as food for the plant" },
  ]);
  const [detailedExplanation, setDetailedExplanation] = useState(
    "Photosynthesis occurs in two main stages: the light-dependent reactions and the light-independent reactions (Calvin cycle). During light-dependent reactions, chlorophyll in the chloroplasts captures light energy, which is used to split water molecules and produce ATP and NADPH. These energy carriers are then used in the Calvin cycle to convert carbon dioxide into glucose. This process takes place primarily in the leaves and is essential for life on Earth as it produces oxygen as a byproduct."
  );
  const [examples, setExamples] = useState([
    "Trees in a forest converting sunlight into energy during the day",
    "Algae in oceans producing oxygen through photosynthesis",
    "Houseplants growing toward windows to maximize light exposure",
  ]);
  const [keyTakeaways, setKeyTakeaways] = useState([
    "Plants use sunlight, water, and CO₂ to make their own food",
    "Oxygen is released as a byproduct",
    "This process is the foundation of most food chains",
  ]);

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg p-8 mb-8 border border-pink-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-pink-300 to-rose-300 rounded-xl flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-3xl text-pink-900">Topic Summary</h1>
        </div>
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="w-full text-4xl font-semibold text-pink-800 bg-transparent border-b-2 border-pink-200 focus:border-pink-400 outline-none pb-2 placeholder-pink-300"
          placeholder="Enter topic name..."
        />
      </div>

      {/* Overview Section */}
      <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg p-8 mb-6 border border-pink-200">
        <div className="flex items-center gap-2 mb-4">
          <Target className="w-5 h-5 text-pink-600" />
          <h2 className="text-xl text-pink-900">Overview</h2>
        </div>
        <textarea
          value={overview}
          onChange={(e) => setOverview(e.target.value)}
          className="w-full text-pink-800 bg-pink-50/50 rounded-xl p-4 border border-pink-200 focus:border-pink-400 outline-none resize-none"
          rows={3}
          placeholder="Brief overview of the topic..."
        />
      </div>

      {/* Key Concepts Grid */}
      <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg p-8 mb-6 border border-pink-200">
        <div className="flex items-center gap-2 mb-6">
          <Lightbulb className="w-5 h-5 text-pink-600" />
          <h2 className="text-xl text-pink-900">Key Concepts</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {keyConcepts.map((concept, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-pink-100 to-rose-100 rounded-2xl p-5 border border-pink-200 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-pink-600 font-semibold">{index + 1}</span>
                </div>
                <div className="flex-1">
                  <input
                    type="text"
                    value={concept.title}
                    onChange={(e) => {
                      const newConcepts = [...keyConcepts];
                      newConcepts[index].title = e.target.value;
                      setKeyConcepts(newConcepts);
                    }}
                    className="w-full font-semibold text-pink-900 bg-transparent border-b border-pink-300 focus:border-pink-500 outline-none mb-2 pb-1"
                    placeholder="Concept title..."
                  />
                  <textarea
                    value={concept.description}
                    onChange={(e) => {
                      const newConcepts = [...keyConcepts];
                      newConcepts[index].description = e.target.value;
                      setKeyConcepts(newConcepts);
                    }}
                    className="w-full text-sm text-pink-700 bg-transparent outline-none resize-none"
                    rows={2}
                    placeholder="Description..."
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Explanation */}
      <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg p-8 mb-6 border border-pink-200">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-pink-600" />
          <h2 className="text-xl text-pink-900">Detailed Explanation</h2>
        </div>
        <textarea
          value={detailedExplanation}
          onChange={(e) => setDetailedExplanation(e.target.value)}
          className="w-full text-pink-800 bg-pink-50/50 rounded-xl p-4 border border-pink-200 focus:border-pink-400 outline-none resize-none leading-relaxed"
          rows={8}
          placeholder="Write a comprehensive explanation..."
        />
      </div>

      {/* Examples Section */}
      <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg p-8 mb-6 border border-pink-200">
        <div className="flex items-center gap-2 mb-4">
          <Star className="w-5 h-5 text-pink-600" />
          <h2 className="text-xl text-pink-900">Real-World Examples</h2>
        </div>
        <div className="space-y-3">
          {examples.map((example, index) => (
            <div key={index} className="flex items-start gap-3 bg-pink-50/50 rounded-xl p-4 border border-pink-200">
              <div className="w-6 h-6 bg-gradient-to-br from-pink-300 to-rose-300 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs font-semibold">{index + 1}</span>
              </div>
              <textarea
                value={example}
                onChange={(e) => {
                  const newExamples = [...examples];
                  newExamples[index] = e.target.value;
                  setExamples(newExamples);
                }}
                className="flex-1 text-pink-800 bg-transparent outline-none resize-none"
                rows={2}
                placeholder="Add an example..."
              />
            </div>
          ))}
        </div>
      </div>

      {/* Quick Review - Key Takeaways */}
      <div className="bg-gradient-to-br from-pink-200 to-rose-200 rounded-3xl shadow-lg p-8 border border-pink-300">
        <div className="flex items-center gap-2 mb-6">
          <CheckCircle2 className="w-6 h-6 text-pink-800" />
          <h2 className="text-xl text-pink-900">Quick Review - Key Takeaways</h2>
        </div>
        <div className="space-y-3">
          {keyTakeaways.map((takeaway, index) => (
            <div
              key={index}
              className="flex items-start gap-3 bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-sm"
            >
              <CheckCircle2 className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
              <textarea
                value={takeaway}
                onChange={(e) => {
                  const newTakeaways = [...keyTakeaways];
                  newTakeaways[index] = e.target.value;
                  setKeyTakeaways(newTakeaways);
                }}
                className="flex-1 text-pink-900 bg-transparent outline-none resize-none font-medium"
                rows={1}
                placeholder="Key takeaway..."
              />
            </div>
          ))}
        </div>
      </div>

      {/* Footer hint */}
      <div className="text-center mt-8 text-pink-600 text-sm">
        Click on any text to edit and customize your topic summary
      </div>
    </div>
  );
}
