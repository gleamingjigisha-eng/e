import { useState } from "react";
import { BookOpen, Clock, Star, ChevronDown, ChevronUp, Lightbulb, Layers, BarChart2, ArrowRight, CheckCircle2, Circle, AlertTriangle, Brain, Zap, Link2, Target } from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import florals from "@/imports/812688695302811731.jpg";
import petri from "@/imports/376121006397179482.jpg";

const topic = {
  subject: "Biology",
  difficulty: "Intermediate",
  readTime: "12 min",
  title: "Photosynthesis",
  subtitle: "How plants convert light into life",
  overview:
    "Photosynthesis is the biochemical process by which green plants, algae, and some bacteria harness sunlight to synthesize nutrients from carbon dioxide and water. It is the foundational energy pathway that sustains nearly all life on Earth — converting radiant energy into chemical energy stored in glucose.",
  keyStats: [
    { value: "~3 billion", label: "Years photosynthesis has existed on Earth" },
    { value: "6CO₂ + 6H₂O", label: "Reactants consumed per cycle" },
    { value: "≈ 70%", label: "Of Earth's oxygen produced by marine plants" },
    { value: "C₆H₁₂O₆ + 6O₂", label: "Products yielded per cycle" },
  ],
  concepts: [
    {
      id: "light",
      icon: "☀️",
      title: "Light-Dependent Reactions",
      accent: "#f3a8be",
      tagBg: "#fce4ec",
      tagText: "#9c3057",
      body: "Occur in the thylakoid membranes. Chlorophyll absorbs photons, energizing electrons that drive the electron transport chain. This produces ATP, NADPH, and releases oxygen as a byproduct of water splitting (photolysis).",
      terms: ["Thylakoid", "Chlorophyll", "Photolysis", "ATP", "NADPH"],
    },
    {
      id: "dark",
      icon: "🌿",
      title: "Calvin Cycle (Light-Independent)",
      accent: "#d4a0b5",
      tagBg: "#f8dde8",
      tagText: "#7a3050",
      body: "Takes place in the stroma of the chloroplast. Uses ATP and NADPH from the light reactions to fix CO₂ into 3-carbon molecules via RuBisCO — the most abundant enzyme on Earth — ultimately assembling glucose for the plant.",
      terms: ["Stroma", "Carbon Fixation", "RuBisCO", "G3P", "Glucose"],
    },
    {
      id: "chloroplast",
      icon: "🔬",
      title: "The Chloroplast",
      accent: "#c088a0",
      tagBg: "#f0d0de",
      tagText: "#6b2545",
      body: "A double-membrane organelle found in plant cells. Its inner membrane system (thylakoids, stacked into grana) houses photosystems I and II. The fluid-filled stroma surrounds the grana and is where the Calvin Cycle runs.",
      terms: ["Thylakoid", "Grana", "Stroma", "Photosystem I & II", "Inner Membrane"],
    },
  ],
  stages: [
    { step: 1, title: "Light Absorption", desc: "Chlorophyll captures photons from sunlight." },
    { step: 2, title: "Water Splitting", desc: "H₂O is split via photolysis, releasing O₂." },
    { step: 3, title: "Energy Carriers Made", desc: "ATP and NADPH are synthesized." },
    { step: 4, title: "CO₂ Fixation", desc: "RuBisCO bonds CO₂ to RuBP in the stroma." },
    { step: 5, title: "Glucose Synthesis", desc: "G3P molecules are assembled into C₆H₁₂O₆." },
  ],
  misconceptions: [
    {
      myth: "Plants get food from soil",
      truth: "Soil provides minerals and water, but glucose — the plant's primary fuel — is self-manufactured via photosynthesis.",
      explanation: "Students often confuse nutrients (minerals like nitrogen, phosphorus) with energy sources. Minerals are building blocks for proteins and other molecules, but they don't provide calories. Plants make their own 'food' (glucose) from scratch using only CO₂, H₂O, and light energy."
    },
    {
      myth: "Photosynthesis only happens in leaves",
      truth: "Any green tissue with chloroplasts (stems, unripe fruit, algae) can photosynthesize.",
      explanation: "While leaves are optimized for photosynthesis with large surface areas and high chloroplast density, the defining factor is chlorophyll presence. Green stems, cacti pads, and even some flower petals perform photosynthesis."
    },
    {
      myth: "Plants only perform photosynthesis",
      truth: "Plants also undergo cellular respiration around the clock to release the energy stored in glucose.",
      explanation: "This is a critical misconception. Plants photosynthesize during daylight to make glucose, then respire 24/7 (day and night) to break down that glucose for usable ATP — just like animals do. At night, plants are net oxygen consumers."
    },
    {
      myth: "Plants breathe CO₂ and exhale O₂",
      truth: "Plants respire O₂ like animals. During photosynthesis they consume CO₂ and release O₂, but during respiration (all the time) they consume O₂ and release CO₂.",
      explanation: "The net effect during daylight is oxygen release because photosynthesis rate exceeds respiration rate. But plants don't 'breathe backwards' — they do both processes simultaneously when light is available."
    },
  ],
  traps: [
    {
      trap: "Confusing light-independent with 'happens in the dark'",
      why: "The Calvin Cycle is called 'light-independent' because it doesn't directly use light, but it requires ATP and NADPH from the light reactions — so it typically happens during daylight.",
      avoid: "Remember: light-independent means 'doesn't directly need photons,' not 'happens at night.' Both stages usually run simultaneously in daylight."
    },
    {
      trap: "Thinking oxygen comes from CO₂",
      why: "The equation shows CO₂ going in and O₂ coming out, but isotope tracing proves O₂ comes from splitting H₂O, not CO₂.",
      avoid: "Use the mnemonic: Water breaks, oxygen escapes. Carbon stays locked in glucose."
    },
    {
      trap: "Assuming all plants use the same photosynthesis pathway",
      why: "C3, C4, and CAM plants use different carbon fixation strategies. Textbook photosynthesis is usually C3.",
      avoid: "Specify 'C3 photosynthesis' when discussing the Calvin Cycle. C4 plants (corn, sugarcane) and CAM plants (cacti) have adaptations for hot/dry climates."
    },
    {
      trap: "Forgetting about RuBP regeneration",
      why: "The Calvin Cycle is a cycle — for every 3 CO₂ fixed, only 1 G3P leaves to make glucose. The other 5 G3P regenerate the 3 RuBP molecules to keep the cycle going.",
      avoid: "Track the math: 3 turns of the cycle = 3 CO₂ in → 1 net G3P out. Two G3P combine to make one glucose (6 carbons)."
    },
  ],
  memoryAids: [
    {
      concept: "Where each stage happens",
      mnemonic: "Thylakoid = Light (both have 'l' and 'i'), Stroma = Dark (both have vowel 'o' and 'a')"
    },
    {
      concept: "Light reaction products",
      mnemonic: "ATP, NADPH, O₂ = ANO (say 'ah-no'). These fuel the Calvin cycle."
    },
    {
      concept: "Calvin Cycle inputs",
      mnemonic: "CO₂ + ATP + NADPH = CAN. The cycle CAN make glucose with these."
    },
    {
      concept: "Photosynthesis vs Respiration",
      mnemonic: "Photo BUILDS (anabolic, endergonic), Respiration BREAKS (catabolic, exergonic). They're exact opposites."
    },
  ],
  whyItMatters: [
    {
      title: "Foundation of Food Chains",
      description: "Every calorie in your body traces back to photosynthesis. Plants are primary producers; herbivores eat plants, carnivores eat herbivores — but it all starts with captured sunlight.",
    },
    {
      title: "Atmospheric Oxygen",
      description: "The Great Oxygenation Event 2.4 billion years ago, triggered by photosynthetic cyanobacteria, transformed Earth's atmosphere and enabled aerobic life.",
    },
    {
      title: "Climate Regulation",
      description: "Photosynthesis is Earth's primary carbon sink. Forests and oceans absorb billions of tons of CO₂ annually, offsetting some human emissions. Deforestation disrupts this balance.",
    },
    {
      title: "Biofuel & Agriculture",
      description: "Improving photosynthetic efficiency in crops (e.g., engineering C4 pathways into rice) could address food security. Algae-based biofuels rely on accelerated photosynthesis.",
    },
  ],
  practiceScenarios: [
    {
      scenario: "A plant is placed in water enriched with H₂¹⁸O (heavy oxygen isotope). After photosynthesis, where will the ¹⁸O appear?",
      answer: "In the O₂ gas released, NOT in glucose",
      reasoning: "Photolysis splits water molecules, releasing O₂. The oxygen in glucose comes from CO₂, not H₂O."
    },
    {
      scenario: "You remove all CO₂ from the air around a plant but keep light on. What happens?",
      answer: "The Calvin Cycle stops; G3P and glucose production cease. ATP and NADPH accumulate, eventually slowing light reactions via feedback inhibition.",
      reasoning: "No CO₂ means no carbon fixation. The light reactions continue briefly but slow down when their products (ATP/NADPH) aren't consumed."
    },
    {
      scenario: "A plant is given light but no water. Can photosynthesis continue?",
      answer: "No — water is essential for both photolysis (O₂ source) and as the electron donor to replace electrons lost by chlorophyll.",
      reasoning: "Water isn't just a reactant in the equation; it's the electron source that keeps photosystem II functional."
    },
  ],
  connections: [
    {
      topic: "Cellular Respiration",
      relationship: "Reverse process — respiration breaks down glucose using O₂ to release energy (ATP), producing CO₂ and H₂O."
    },
    {
      topic: "Electron Transport Chain",
      relationship: "Both photosynthesis and respiration use ETC to generate ATP via chemiosmosis. Different locations and electron sources, same mechanism."
    },
    {
      topic: "Krebs Cycle (Citric Acid Cycle)",
      relationship: "Like the Calvin Cycle, the Krebs Cycle is a circular metabolic pathway. Both regenerate their starting compounds to sustain continuous operation."
    },
    {
      topic: "C4 and CAM Photosynthesis",
      relationship: "Variations that minimize photorespiration (wasteful RuBisCO reaction with O₂) in hot, dry climates. Same end products, different carbon-fixing front-end."
    },
  ],
  summary: [
    "Photosynthesis converts light energy into chemical energy (glucose).",
    "Two stages: light-dependent reactions (thylakoid) and the Calvin Cycle (stroma).",
    "Requires CO₂, H₂O, and light; yields glucose and O₂.",
    "Chlorophyll absorbs mostly red and blue wavelengths.",
    "RuBisCO is the key enzyme for carbon fixation in the Calvin Cycle.",
    "Oxygen released comes from water splitting (photolysis), not CO₂.",
    "Plants perform both photosynthesis (daylight) and respiration (24/7).",
    "The Calvin Cycle is light-independent but requires ATP/NADPH from light reactions.",
  ],
};

function DifficultyBadge({ level }: { level: string }) {
  const map: Record<string, string> = {
    Beginner: "bg-emerald-100 text-emerald-700 border-emerald-200",
    Intermediate: "bg-rose-100 text-rose-600 border-rose-200",
    Advanced: "bg-red-100 text-red-700 border-red-200",
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-mono font-medium border ${map[level] ?? ""}`}>
      <Star size={10} strokeWidth={2.5} />
      {level}
    </span>
  );
}

function ConceptCard({ concept }: { concept: typeof topic.concepts[0] }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className="relative overflow-hidden rounded-2xl border transition-all duration-300"
      style={{
        borderColor: concept.accent + "55",
        background: `linear-gradient(135deg, #fff8fa 0%, #fff0f4 100%)`,
        boxShadow: open ? `0 8px 32px ${concept.accent}30, 0 2px 8px ${concept.accent}15` : `0 2px 8px ${concept.accent}18`,
      }}
    >
      {/* Side accent bar */}
      <div className="absolute left-0 top-0 bottom-0 w-1 rounded-l-2xl" style={{ background: concept.accent }} />

      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between gap-3 pl-6 pr-5 py-5 text-left"
      >
        <div className="flex items-center gap-3">
          <span className="text-2xl leading-none">{concept.icon}</span>
          <span className="font-semibold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
            {concept.title}
          </span>
        </div>
        <span className="text-muted-foreground shrink-0 transition-transform duration-200" style={{ transform: open ? "rotate(180deg)" : "rotate(0)" }}>
          <ChevronDown size={16} />
        </span>
      </button>

      {open && (
        <div className="pl-6 pr-5 pb-5 space-y-3">
          <p className="text-sm text-foreground/75 leading-relaxed">{concept.body}</p>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {concept.terms.map((t) => (
              <span
                key={t}
                className="text-xs font-mono px-2 py-0.5 rounded-full font-medium"
                style={{ background: concept.tagBg, color: concept.tagText }}
              >
                {t}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [checkedItems, setCheckedItems] = useState<Set<number>>(new Set());
  const [revealedScenarios, setRevealedScenarios] = useState<Set<number>>(new Set());
  
  const toggleCheck = (i: number) =>
    setCheckedItems((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });

  const toggleReveal = (i: number) =>
    setRevealedScenarios((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });

  const progress = Math.round((checkedItems.size / topic.summary.length) * 100);

  return (
    <div className="min-h-screen bg-background" style={{ fontFamily: "'DM Sans', sans-serif" }}>

      {/* Sticky header */}
      <header className="sticky top-0 z-30 backdrop-blur-md border-b border-border px-6 py-3 flex items-center justify-between" style={{ background: "rgba(253,240,243,0.85)" }}>
        <div className="flex items-center gap-2 text-muted-foreground text-sm">
          <BookOpen size={15} />
          <span className="font-mono">{topic.subject}</span>
          <span className="opacity-40">·</span>
          <Clock size={13} />
          <span>{topic.readTime}</span>
        </div>
        <DifficultyBadge level={topic.difficulty} />
      </header>

      {/* ── HERO ── */}
      <section className="relative overflow-hidden" style={{ minHeight: 480 }}>
        {/* Floral image — fills right side, fades out left */}
        <div className="absolute inset-0 pointer-events-none select-none">
          <div className="absolute right-0 top-0 w-[55%] h-full">
            <ImageWithFallback
              src={florals}
              alt="Cascading soft pink blossoms"
              className="w-full h-full object-cover object-left"
            />
            {/* Left fade */}
            <div className="absolute inset-0" style={{ background: "linear-gradient(to right, #fdf0f3 0%, transparent 55%)" }} />
          </div>
          {/* Full bottom fade */}
          <div className="absolute bottom-0 left-0 right-0 h-32" style={{ background: "linear-gradient(to bottom, transparent 0%, #fdf0f3 100%)" }} />
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-3xl mx-auto px-5 pt-16 pb-20">
          <div className="inline-block font-mono text-xs uppercase tracking-widest px-3 py-1 rounded-full mb-5" style={{ background: "rgba(196,94,122,0.12)", color: "#c45e7a" }}>
            Topic Overview
          </div>
          <h1
            className="text-6xl font-bold leading-tight text-foreground mb-3"
            style={{ fontFamily: "'Playfair Display', serif", textShadow: "0 2px 24px rgba(196,94,122,0.08)" }}
          >
            {topic.title}
          </h1>
          <p className="text-xl italic text-muted-foreground mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            {topic.subtitle}
          </p>
          <p className="text-base text-foreground/70 leading-relaxed max-w-[48ch]">
            {topic.overview}
          </p>
        </div>
      </section>

      <main className="max-w-3xl mx-auto px-5 pb-16 space-y-16">

        {/* ── KEY STATS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <BarChart2 size={18} className="text-primary" />
            At a Glance
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {topic.keyStats.map((s, i) => (
              <div
                key={s.label}
                className="rounded-2xl p-4 space-y-1 group transition-all duration-200 hover:-translate-y-0.5"
                style={{
                  background: "linear-gradient(135deg, #fff5f7 0%, #fce8ef 100%)",
                  border: "1px solid rgba(196,94,122,0.18)",
                  boxShadow: "0 2px 12px rgba(196,94,122,0.08)",
                  transitionProperty: "transform, box-shadow",
                }}
                onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 8px 28px rgba(196,94,122,0.18)")}
                onMouseLeave={e => (e.currentTarget.style.boxShadow = "0 2px 12px rgba(196,94,122,0.08)")}
              >
                <p className="text-lg font-bold text-primary leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {s.value}
                </p>
                <p className="text-xs text-muted-foreground leading-snug">{s.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── PETRI DISH EQUATION ── */}
        <section className="flex flex-col sm:flex-row items-center gap-8">
          {/* Circular specimen */}
          <div className="relative shrink-0" style={{ width: 220, height: 220 }}>
            {/* Outer glass ring */}
            <div
              className="absolute inset-0 rounded-full"
              style={{
                border: "1.5px solid rgba(196,94,122,0.35)",
                boxShadow: "0 0 0 8px rgba(196,94,122,0.06), 0 12px 40px rgba(196,94,122,0.18)",
              }}
            />
            {/* Image fills the circle */}
            <div className="absolute inset-2 rounded-full overflow-hidden">
              <ImageWithFallback
                src={petri}
                alt="Flower in a scientific petri dish, dusty rose on blush"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Bubble dots scattered around ring */}
            {[
              { top: "8%", left: "72%", size: 8, opacity: 0.45 },
              { top: "18%", left: "84%", size: 5, opacity: 0.3 },
              { top: "68%", left: "88%", size: 6, opacity: 0.35 },
              { top: "80%", left: "20%", size: 7, opacity: 0.4 },
              { top: "12%", left: "14%", size: 5, opacity: 0.25 },
            ].map((b, i) => (
              <div
                key={i}
                className="absolute rounded-full"
                style={{
                  top: b.top, left: b.left,
                  width: b.size, height: b.size,
                  background: `rgba(196,94,122,${b.opacity})`,
                  transform: "translate(-50%,-50%)",
                }}
              />
            ))}
          </div>

          {/* Equation text */}
          <div className="flex-1 space-y-4">
            <p className="text-xs font-mono uppercase tracking-widest text-primary/60">The Master Equation</p>
            <div
              className="rounded-2xl p-6 space-y-3"
              style={{
                background: "linear-gradient(135deg, #fff5f7 0%, #fce8ef 100%)",
                border: "1px solid rgba(196,94,122,0.2)",
                boxShadow: "0 4px 24px rgba(196,94,122,0.1)",
              }}
            >
              <p className="text-xl font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
                6CO₂ + 6H₂O + light
              </p>
              <div className="flex items-center gap-2">
                <div className="h-px flex-1 bg-primary/15" />
                <ArrowRight size={15} className="text-primary/50" />
                <div className="h-px flex-1 bg-primary/15" />
              </div>
              <p className="text-xl font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
                C₆H₁₂O₆ + 6O₂
              </p>
            </div>
          </div>
        </section>

        {/* ── CORE CONCEPTS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <Layers size={18} className="text-primary" />
            Core Concepts
          </h2>
          <p className="text-sm text-muted-foreground mb-5">Tap each card to expand.</p>
          <div className="space-y-3">
            {topic.concepts.map((c) => (
              <ConceptCard key={c.id} concept={c} />
            ))}
          </div>
        </section>

        {/* ── STEP-BY-STEP PROCESS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <ArrowRight size={18} className="text-primary" />
            Step-by-Step Process
          </h2>
          <div className="relative pl-4">
            {/* Connecting line */}
            <div className="absolute left-[1.9rem] top-4 bottom-4 w-px" style={{ background: "linear-gradient(to bottom, #f3a8be, #c45e7a55)" }} />
            <div className="space-y-0">
              {topic.stages.map((s, i) => (
                <div key={s.step} className="flex gap-5 items-start pb-7 last:pb-0">
                  <div
                    className="relative z-10 w-9 h-9 rounded-full flex items-center justify-center text-xs font-mono font-semibold shrink-0 text-white"
                    style={{
                      background: `linear-gradient(135deg, #e8a0b4 0%, #c45e7a 100%)`,
                      boxShadow: "0 2px 12px rgba(196,94,122,0.3)",
                    }}
                  >
                    {s.step}
                  </div>
                  <div className="pt-1.5">
                    <p className="font-semibold text-sm text-foreground">{s.title}</p>
                    <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── MISCONCEPTIONS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <Lightbulb size={18} className="text-primary" />
            Common Misconceptions
          </h2>
          <div className="space-y-3">
            {topic.misconceptions.map((m, i) => (
              <div
                key={i}
                className="rounded-2xl p-5 space-y-3"
                style={{
                  background: "linear-gradient(135deg, #fff5f7 0%, #fce8ef 100%)",
                  border: "1px solid rgba(196,94,122,0.15)",
                  boxShadow: "0 2px 12px rgba(196,94,122,0.06)",
                }}
              >
                <div className="grid sm:grid-cols-[1fr_32px_1fr] gap-4 items-start">
                  <div>
                    <p className="text-xs font-mono uppercase tracking-wide mb-1.5" style={{ color: "#b05070" }}>Myth</p>
                    <p className="text-sm text-foreground font-medium leading-snug">"{m.myth}"</p>
                  </div>
                  <div className="hidden sm:flex items-center justify-center pt-6">
                    <ArrowRight size={15} className="text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase tracking-wide mb-1.5" style={{ color: "#5a8a60" }}>Reality</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{m.truth}</p>
                  </div>
                </div>
                <div className="pt-2 pl-0 border-t border-primary/10">
                  <p className="text-xs text-muted-foreground/80 leading-relaxed italic">{m.explanation}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── COMMON TRAPS & PITFALLS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <AlertTriangle size={18} className="text-primary" />
            Common Traps & Pitfalls
          </h2>
          <div className="space-y-3">
            {topic.traps.map((t, i) => (
              <div
                key={i}
                className="rounded-2xl p-5 space-y-2.5"
                style={{
                  background: "linear-gradient(135deg, #fffaf7 0%, #ffeef0 100%)",
                  border: "1.5px solid rgba(196,94,122,0.2)",
                  boxShadow: "0 2px 12px rgba(196,94,122,0.08)",
                }}
              >
                <div className="flex items-start gap-2">
                  <span className="text-lg mt-0.5">⚠️</span>
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-foreground leading-snug">{t.trap}</p>
                  </div>
                </div>
                <div className="pl-7 space-y-2">
                  <div>
                    <p className="text-xs font-mono uppercase tracking-wide mb-1" style={{ color: "#b05070" }}>Why this happens</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{t.why}</p>
                  </div>
                  <div>
                    <p className="text-xs font-mono uppercase tracking-wide mb-1" style={{ color: "#5a8a60" }}>How to avoid</p>
                    <p className="text-sm text-foreground/80 leading-relaxed">{t.avoid}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── MEMORY AIDS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <Brain size={18} className="text-primary" />
            Memory Aids & Mnemonics
          </h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {topic.memoryAids.map((aid, i) => (
              <div
                key={i}
                className="rounded-2xl p-5 space-y-2 group hover:-translate-y-0.5 transition-all duration-200"
                style={{
                  background: "linear-gradient(135deg, #f9f5ff 0%, #f3e8f7 100%)",
                  border: "1px solid rgba(160,94,196,0.2)",
                  boxShadow: "0 2px 12px rgba(160,94,196,0.08)",
                  transitionProperty: "transform, box-shadow",
                }}
                onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 8px 28px rgba(160,94,196,0.16)")}
                onMouseLeave={e => (e.currentTarget.style.boxShadow = "0 2px 12px rgba(160,94,196,0.08)")}
              >
                <p className="text-xs font-mono uppercase tracking-wide text-purple-700/70">{aid.concept}</p>
                <p className="text-sm font-medium text-foreground leading-snug" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {aid.mnemonic}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ── WHY IT MATTERS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <Zap size={18} className="text-primary" />
            Why It Matters
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {topic.whyItMatters.map((item, i) => (
              <div
                key={i}
                className="rounded-2xl p-5 space-y-2"
                style={{
                  background: "linear-gradient(135deg, #f0faf5 0%, #e8f5f0 100%)",
                  border: "1px solid rgba(94,166,122,0.25)",
                  boxShadow: "0 2px 12px rgba(94,166,122,0.08)",
                }}
              >
                <p className="font-semibold text-sm text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {item.title}
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── PRACTICE SCENARIOS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <Target size={18} className="text-primary" />
            Practice Scenarios
          </h2>
          <div className="space-y-4">
            {topic.practiceScenarios.map((ps, i) => {
              const revealed = revealedScenarios.has(i);
              return (
                <div
                  key={i}
                  className="rounded-2xl overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, #fffbf5 0%, #fff4e8 100%)",
                    border: "1px solid rgba(196,142,94,0.25)",
                    boxShadow: "0 2px 12px rgba(196,142,94,0.08)",
                  }}
                >
                  <div className="p-5 space-y-3">
                    <div className="flex items-start gap-2">
                      <span className="text-lg mt-0.5">🧪</span>
                      <p className="text-sm text-foreground leading-relaxed flex-1">{ps.scenario}</p>
                    </div>
                    <button
                      onClick={() => toggleReveal(i)}
                      className="text-xs font-mono uppercase tracking-wide px-3 py-1.5 rounded-full transition-colors"
                      style={{
                        background: revealed ? "rgba(196,142,94,0.15)" : "rgba(196,142,94,0.1)",
                        color: "#8b5e3c",
                      }}
                    >
                      {revealed ? "Hide Answer" : "Show Answer"}
                    </button>
                    {revealed && (
                      <div className="pt-3 space-y-2 border-t border-primary/10">
                        <div>
                          <p className="text-xs font-mono uppercase tracking-wide mb-1" style={{ color: "#5a8a60" }}>Answer</p>
                          <p className="text-sm font-medium text-foreground">{ps.answer}</p>
                        </div>
                        <div>
                          <p className="text-xs font-mono uppercase tracking-wide mb-1 text-muted-foreground">Reasoning</p>
                          <p className="text-sm text-muted-foreground leading-relaxed">{ps.reasoning}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* ── CONNECTIONS TO OTHER TOPICS ── */}
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-5 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            <Link2 size={18} className="text-primary" />
            Connections to Other Topics
          </h2>
          <div className="space-y-2.5">
            {topic.connections.map((conn, i) => (
              <div
                key={i}
                className="rounded-xl p-4 flex items-start gap-3"
                style={{
                  background: "linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%)",
                  border: "1px solid rgba(139,94,196,0.2)",
                  boxShadow: "0 1px 8px rgba(139,94,196,0.06)",
                }}
              >
                <ArrowRight size={14} className="text-primary/50 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <p className="font-semibold text-sm text-foreground">{conn.topic}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed mt-0.5">{conn.relationship}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── QUICK REVIEW ── */}
        <section>
          <div
            className="relative overflow-hidden rounded-3xl p-7 space-y-5"
            style={{
              background: "linear-gradient(135deg, #fff0f4 0%, #fce4ed 100%)",
              border: "1px solid rgba(196,94,122,0.2)",
              boxShadow: "0 8px 40px rgba(196,94,122,0.12)",
            }}
          >
            {/* Decorative petal silhouette top-right */}
            <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full pointer-events-none select-none opacity-[0.06]" style={{ background: "#c45e7a" }} />
            <div className="absolute -top-4 -right-4 w-28 h-28 rounded-full pointer-events-none select-none opacity-[0.07]" style={{ background: "#c45e7a" }} />

            <div className="relative flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground flex items-center gap-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                <CheckCircle2 size={18} className="text-primary" />
                Quick Review
              </h2>
              <span className="text-xs font-mono text-muted-foreground">{checkedItems.size}/{topic.summary.length} understood</span>
            </div>

            {/* Progress bar */}
            <div className="h-2 rounded-full overflow-hidden" style={{ background: "rgba(196,94,122,0.15)" }}>
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${progress}%`,
                  background: "linear-gradient(to right, #e8a0b4, #c45e7a)",
                }}
              />
            </div>

            <ul className="space-y-3 relative">
              {topic.summary.map((point, i) => {
                const checked = checkedItems.has(i);
                return (
                  <li key={i}>
                    <button
                      onClick={() => toggleCheck(i)}
                      className="w-full flex items-start gap-3 text-left group"
                    >
                      <span
                        className="mt-0.5 shrink-0 transition-colors"
                        style={{ color: checked ? "#c45e7a" : "#d4a0b5" }}
                      >
                        {checked ? <CheckCircle2 size={17} /> : <Circle size={17} />}
                      </span>
                      <span
                        className="text-sm leading-relaxed transition-colors"
                        style={{ color: checked ? "#b08090" : "#2d1a20", textDecoration: checked ? "line-through" : "none" }}
                      >
                        {point}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>

            {checkedItems.size === topic.summary.length && (
              <div className="text-center pt-2">
                <p className="text-sm font-semibold" style={{ fontFamily: "'Playfair Display', serif", color: "#c45e7a" }}>
                  🌸 Topic mastered — well done!
                </p>
              </div>
            )}
          </div>
        </section>

        {/* Footer */}
        <footer className="text-center text-xs text-muted-foreground pb-4 space-y-1">
          <p className="font-mono">{topic.subject} · {topic.difficulty} · {topic.readTime} read</p>
          <p>Educational template · swap the topic object to repopulate</p>
        </footer>
      </main>
    </div>
  );
}